PhoneResponsive={"785":{
"pageLayer":{"w":785,"h":450,"bgColor":"#00324b","bgImage":"images/image0000.png","bgSize":"785px 441px","bgRepeat":"no-repeat"}
,
"":{"x":275,"y":142,"w":233,"h":156,"bOffBottom":0}
,
"":{"x":275,"y":142,"w":233,"h":156,"bOffBottom":0}
,
"image10864":{"x":0,"y":0,"w":785,"h":93,"bOffBottom":0,"i":"images/image0014.png"}
,
"shape3495":{"x":75,"y":313,"w":635.000000,"h":4.000000,"stylemods":[{"sel":"div.shape3495Text","decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:631.000000px; height:0.000000px;}"},{"sel":"span.shape3495Text","decl":" { width:627.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAnkAAAACCAYAAAAkc8qKAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cExAQAAAMKg9U9tDQ8gAAAAAOBeDRPKAAHjSqiOAAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 2.000000 2.000000 L 633.000000 2.000000 "}
,
"shape3497":{"x":75,"y":163,"w":635.000000,"h":4.000000,"stylemods":[{"sel":"div.shape3497Text","decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:631.000000px; height:0.000000px;}"},{"sel":"span.shape3497Text","decl":" { width:627.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAnkAAAACCAYAAAAkc8qKAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cExAQAAAMKg9U9tDQ8gAAAAAOBeDRPKAAHjSqiOAAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 2.000000 2.000000 L 633.000000 2.000000 "}
,
"shape3499":{"x":335,"y":134,"w":110.000000,"h":38.000000,"stylemods":[{"sel":"div.shape3499Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:109.000000px; height:37.000000px;}"},{"sel":"span.shape3499Text","decl":" { width:105.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAG4AAAAmCAYAAAAlUK76AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAmSURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAh2pBdgABcW4DegAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 109.000000 0.000000 L 109.000000 37.000000 L 0.000000 37.000000 L 0.000000 0.000000 z"}
,
"text3501":{"x":196,"y":138,"w":391,"h":40,"txtscale":100,"bOffBottom":0}
,
"text3502":{"x":54,"y":184,"w":674,"h":93,"txtscale":100,"bOffBottom":0}
,
"text3503":{"x":19,"y":257,"w":747,"h":52,"txtscale":100,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":[]
},
"480":{
"pageLayer":{"w":480,"h":763,"bgColor":"#00324b","bgImage":"images/image0000.png","bgSize":"480px 270px","bgRepeat":"no-repeat"}
,
"":{"x":168,"y":183,"w":143,"h":95,"bOffBottom":0}
,
"":{"x":168,"y":183,"w":143,"h":95,"bOffBottom":0}
,
"image10864":{"x":0,"y":0,"w":480,"h":57,"bOffBottom":0,"i":"images/image0014.png"}
,
"shape3495":{"x":46,"y":403,"w":390.000000,"h":4.000000,"stylemods":[{"sel":"div.shape3495Text","decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:386.000000px; height:0.000000px;}"},{"sel":"span.shape3495Text","decl":" { width:382.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAYQAAAACCAYAAABYI6uiAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAaSURBVEhL7cExAQAAAMKg9U/tYwwgAACAqwEMIgABS4x0zAAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 2.000000 2.000000 L 388.000000 2.000000 "}
,
"shape3497":{"x":46,"y":210,"w":390.000000,"h":4.000000,"stylemods":[{"sel":"div.shape3497Text","decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:386.000000px; height:0.000000px;}"},{"sel":"span.shape3497Text","decl":" { width:382.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAYQAAAACCAYAAABYI6uiAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAaSURBVEhL7cExAQAAAMKg9U/tYwwgAACAqwEMIgABS4x0zAAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 2.000000 2.000000 L 388.000000 2.000000 "}
,
"shape3499":{"x":205,"y":172,"w":68.000000,"h":23.000000,"stylemods":[{"sel":"div.shape3499Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:67.000000px; height:22.000000px;}"},{"sel":"span.shape3499Text","decl":" { width:63.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEQAAAAXCAYAAACyCenrAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAdSURBVFhH7cExAQAAAMKg9U9tCj8gAAAAAACAhxoYhwABJBo12gAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 67.000000 0.000000 L 67.000000 22.000000 L 0.000000 22.000000 L 0.000000 0.000000 z"}
,
"text3501":{"x":120,"y":178,"w":239,"h":40,"txtscale":100,"bOffBottom":0}
,
"text3502":{"x":33,"y":236,"w":412,"h":93,"txtscale":100,"bOffBottom":0}
,
"text3503":{"x":11,"y":330,"w":457,"h":92,"txtscale":100,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":[]
}}

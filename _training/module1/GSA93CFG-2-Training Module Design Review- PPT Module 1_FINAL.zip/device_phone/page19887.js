PhoneResponsive={"785":{
"pageLayer":{"w":785,"h":450,"bgColor":"#00324b","bgImage":"images/image0004.png","bgSize":"785px 441px","bgRepeat":"no-repeat"}
,
"":{"x":275,"y":142,"w":233,"h":156,"bOffBottom":0}
,
"":{"x":275,"y":142,"w":233,"h":156,"bOffBottom":0}
,
"image10864":{"x":0,"y":0,"w":785,"h":93,"bOffBottom":0,"i":"images/image0014.png"}
,
"text208202":{"x":700,"y":402,"w":54,"h":15,"txtscale":100,"bOffBottom":0}
,
"text208200":{"x":58,"y":402,"w":49,"h":16,"txtscale":100,"bOffBottom":0}
,
"image10862":{"x":51,"y":406,"w":37,"h":13,"bOffBottom":0,"i":"images/image0002.png"}
,
"image10860":{"x":699,"y":406,"w":37,"h":13,"bOffBottom":0,"i":"images/image0003.png"}
,
"button10847":{"B64":{"disabledState":"","downState":"","normalState":"","overState":"","selectedState":"","visitedState":""},"bOffBottom":0,"h":37,"p":"M 9.000000 0.000000 L 76.000000 0.000000 L 77.812500 0.187500 L 79.500000 0.687500 L 82.375000 2.625000 L 84.312500 5.500000 L 85.000000 9.000000 L 85.000000 27.000000 L 84.312500 30.500000 L 82.375000 33.375000 L 79.500000 35.312500 L 76.000000 36.000000 L 9.000000 36.000000 L 5.562500 35.312500 L 2.687500 33.375000 L 0.687500 30.500000 L 0.000000 27.000000 L 0.000000 9.000000 L 0.187500 7.187500 L 0.687500 5.500000 L 2.625000 2.625000 L 5.500000 0.687500 L 7.187500 0.187500 L 9.000000 0.000000 z","stylemods":[{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10847Text"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10847overStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847overStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10847downStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847downStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10847disabledStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847disabledStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10847visitedStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847visitedStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10847selectedStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847selectedStateText"}],"w":86,"x":39,"y":398}
,
"button10855":{"B64":{"disabledState":"","downState":"","normalState":"","overState":"","selectedState":"","visitedState":""},"bOffBottom":0,"h":37,"p":"M 9.000000 0.000000 L 76.000000 0.000000 L 77.812500 0.187500 L 79.500000 0.687500 L 82.375000 2.625000 L 84.312500 5.500000 L 85.000000 9.000000 L 85.000000 27.000000 L 84.312500 30.500000 L 82.375000 33.375000 L 79.500000 35.312500 L 76.000000 36.000000 L 9.000000 36.000000 L 5.562500 35.312500 L 2.687500 33.375000 L 0.687500 30.500000 L 0.000000 27.000000 L 0.000000 9.000000 L 0.187500 7.187500 L 0.687500 5.500000 L 2.625000 2.625000 L 5.500000 0.687500 L 7.187500 0.187500 L 9.000000 0.000000 z","stylemods":[{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10855Text"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10855overStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855overStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10855downStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855downStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10855disabledStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855disabledStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10855visitedStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855visitedStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10855selectedStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855selectedStateText"}],"w":86,"x":661,"y":398}
,
"progress187611":{"x":54,"y":419,"w":678,"h":14,"bOffBottom":0,"vert":0,"barImage":"images/PhoneLandscape_progress187611_bar.png","bgImage":"images/PhoneLandscape_progress187611.png"}
,
"text196428":{"x":400,"y":420,"w":24,"h":18,"txtscale":100,"bOffBottom":0}
,
"text19888":{"x":51,"y":148,"w":685,"h":79,"txtscale":100,"bOffBottom":0}
,
"text19889":{"x":53,"y":113,"w":342,"h":38,"txtscale":100,"bOffBottom":0}
,
"shape19891":{"x":78,"y":202,"w":280.000000,"h":65.000000,"stylemods":[{"sel":"div.shape19891Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:279.000000px; height:64.000000px;}"},{"sel":"span.shape19891Text","decl":" { width:275.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARgAAABBCAYAAAAKeLsHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABeSURBVHhe7cExAQAAAMKg9U9tCy8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPipARywAAHqMj7tAAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 0.000000 0.000000 L 279.000000 0.000000 L 279.000000 64.000000 L 0.000000 64.000000 L 0.000000 0.000000 z"}
,
"image19893":{"x":59,"y":211,"w":41,"h":41,"bOffBottom":0,"i":"images/image0065.png"}
,
"shape19895":{"x":78,"y":275,"w":280.000000,"h":69.000000,"stylemods":[{"sel":"div.shape19895Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:279.000000px; height:68.000000px;}"},{"sel":"span.shape19895Text","decl":" { width:275.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARgAAABFCAYAAACR6fkRAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABiSURBVHhe7cEBDQAAAMKg909tDwcEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8qQEuNAABHnUVEgAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 279.000000 0.000000 L 279.000000 68.000000 L 0.000000 68.000000 L 0.000000 0.000000 z"}
,
"image19897":{"x":59,"y":289,"w":41,"h":41,"bOffBottom":0,"i":"images/image69.png"}
,
"shape19899":{"x":436,"y":202,"w":280.000000,"h":65.000000,"stylemods":[{"sel":"div.shape19899Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:279.000000px; height:64.000000px;}"},{"sel":"span.shape19899Text","decl":" { width:275.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARgAAABBCAYAAAAKeLsHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABeSURBVHhe7cExAQAAAMKg9U9tCy8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPipARywAAHqMj7tAAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 0.000000 0.000000 L 279.000000 0.000000 L 279.000000 64.000000 L 0.000000 64.000000 L 0.000000 0.000000 z"}
,
"image19901":{"x":417,"y":211,"w":41,"h":41,"bOffBottom":0,"i":"images/image0066.png"}
,
"shape19903":{"x":436,"y":275,"w":280.000000,"h":69.000000,"stylemods":[{"sel":"div.shape19903Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:279.000000px; height:68.000000px;}"},{"sel":"span.shape19903Text","decl":" { width:275.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARgAAABFCAYAAACR6fkRAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABiSURBVHhe7cEBDQAAAMKg909tDwcEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8qQEuNAABHnUVEgAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 279.000000 0.000000 L 279.000000 68.000000 L 0.000000 68.000000 L 0.000000 0.000000 z"}
,
"image19905":{"x":417,"y":289,"w":41,"h":41,"bOffBottom":0,"i":"images/image70.png"}
,
"text19906":{"x":112,"y":211,"w":227,"h":45,"txtscale":100,"bOffBottom":0}
,
"text29927":{"x":112,"y":288,"w":230,"h":60,"txtscale":100,"bOffBottom":0}
,
"text29937":{"x":468,"y":216,"w":223,"h":60,"txtscale":100,"bOffBottom":0}
,
"text29984":{"x":468,"y":288,"w":267,"h":45,"txtscale":100,"bOffBottom":0}
,
"text19907":{"x":58,"y":357,"w":696,"h":34,"txtscale":100,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":[]
},
"480":{
"pageLayer":{"w":480,"h":763,"bgColor":"#00324b","bgImage":"images/image0004.png","bgSize":"480px 270px","bgRepeat":"no-repeat"}
,
"":{"x":168,"y":183,"w":143,"h":95,"bOffBottom":0}
,
"":{"x":168,"y":183,"w":143,"h":95,"bOffBottom":0}
,
"image10864":{"x":0,"y":0,"w":480,"h":57,"bOffBottom":0,"i":"images/image0014.png"}
,
"text208202":{"x":428,"y":517,"w":33,"h":15,"txtscale":100,"bOffBottom":0}
,
"text208200":{"x":36,"y":517,"w":30,"h":15,"txtscale":100,"bOffBottom":0}
,
"image10862":{"x":31,"y":522,"w":22,"h":8,"bOffBottom":0,"i":"images/image0002.png"}
,
"image10860":{"x":427,"y":522,"w":23,"h":8,"bOffBottom":0,"i":"images/image0003.png"}
,
"button10847":{"B64":{"disabledState":"","downState":"","normalState":"","overState":"","selectedState":"","visitedState":""},"bOffBottom":0,"h":23,"p":"M 5.000000 0.000000 L 47.000000 0.000000 L 48.937500 0.375000 L 50.562500 1.500000 L 51.625000 3.062500 L 52.000000 5.000000 L 52.000000 17.000000 L 51.625000 18.937500 L 50.562500 20.562500 L 48.937500 21.625000 L 47.000000 22.000000 L 5.000000 22.000000 L 3.125000 21.625000 L 1.500000 20.562500 L 0.375000 18.937500 L 0.000000 17.000000 L 0.000000 5.000000 L 0.375000 3.062500 L 1.500000 1.500000 L 3.062500 0.375000 L 5.000000 0.000000 z","stylemods":[{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10847Text"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10847overStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847overStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10847downStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847downStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10847disabledStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847disabledStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10847visitedStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847visitedStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10847selectedStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847selectedStateText"}],"w":53,"x":24,"y":512}
,
"button10855":{"B64":{"disabledState":"","downState":"","normalState":"","overState":"","selectedState":"","visitedState":""},"bOffBottom":0,"h":23,"p":"M 5.000000 0.000000 L 47.000000 0.000000 L 48.937500 0.375000 L 50.562500 1.500000 L 51.625000 3.062500 L 52.000000 5.000000 L 52.000000 17.000000 L 51.625000 18.937500 L 50.562500 20.562500 L 48.937500 21.625000 L 47.000000 22.000000 L 5.000000 22.000000 L 3.125000 21.625000 L 1.500000 20.562500 L 0.375000 18.937500 L 0.000000 17.000000 L 0.000000 5.000000 L 0.375000 3.062500 L 1.500000 1.500000 L 3.062500 0.375000 L 5.000000 0.000000 z","stylemods":[{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10855Text"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10855overStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855overStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10855downStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855downStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10855disabledStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855disabledStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10855visitedStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855visitedStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10855selectedStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855selectedStateText"}],"w":53,"x":404,"y":512}
,
"progress187611":{"x":33,"y":539,"w":415,"h":9,"bOffBottom":0,"vert":0,"barImage":"images/PhonePortrait_progress187611_bar.png","bgImage":"images/PhonePortrait_progress187611.png"}
,
"text196428":{"x":245,"y":540,"w":15,"h":17,"txtscale":100,"bOffBottom":0}
,
"text19888":{"x":31,"y":190,"w":419,"h":79,"txtscale":100,"bOffBottom":0}
,
"text19889":{"x":32,"y":145,"w":209,"h":64,"txtscale":100,"bOffBottom":0}
,
"shape19891":{"x":48,"y":259,"w":171.000000,"h":40.000000,"stylemods":[{"sel":"div.shape19891Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:170.000000px; height:39.000000px;}"},{"sel":"span.shape19891Text","decl":" { width:166.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKsAAAAoCAYAAACBzApvAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAySURBVHhe7cExAQAAAMKg9U9tBn8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC41QBrCAABBV9F7AAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 170.000000 0.000000 L 170.000000 39.000000 L 0.000000 39.000000 L 0.000000 0.000000 z"}
,
"image19893":{"x":36,"y":271,"w":25,"h":25,"bOffBottom":0,"i":"images/image0065.png"}
,
"shape19895":{"x":48,"y":354,"w":171.000000,"h":42.000000,"stylemods":[{"sel":"div.shape19895Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:170.000000px; height:41.000000px;}"},{"sel":"span.shape19895Text","decl":" { width:166.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKsAAAAqCAYAAADMBKtkAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAzSURBVHhe7cExAQAAAMKg9U9tDB8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4K4GcGIAAWGgzv4AAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 170.000000 0.000000 L 170.000000 41.000000 L 0.000000 41.000000 L 0.000000 0.000000 z"}
,
"image19897":{"x":36,"y":371,"w":25,"h":25,"bOffBottom":0,"i":"images/image69.png"}
,
"shape19899":{"x":266,"y":259,"w":171.000000,"h":40.000000,"stylemods":[{"sel":"div.shape19899Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:170.000000px; height:39.000000px;}"},{"sel":"span.shape19899Text","decl":" { width:166.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKsAAAAoCAYAAACBzApvAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAySURBVHhe7cExAQAAAMKg9U9tBn8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC41QBrCAABBV9F7AAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 170.000000 0.000000 L 170.000000 39.000000 L 0.000000 39.000000 L 0.000000 0.000000 z"}
,
"image19901":{"x":255,"y":271,"w":25,"h":25,"bOffBottom":0,"i":"images/image0066.png"}
,
"shape19903":{"x":266,"y":354,"w":171.000000,"h":42.000000,"stylemods":[{"sel":"div.shape19903Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:170.000000px; height:41.000000px;}"},{"sel":"span.shape19903Text","decl":" { width:166.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKsAAAAqCAYAAADMBKtkAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAzSURBVHhe7cExAQAAAMKg9U9tDB8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4K4GcGIAAWGgzv4AAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 170.000000 0.000000 L 170.000000 41.000000 L 0.000000 41.000000 L 0.000000 0.000000 z"}
,
"image19905":{"x":255,"y":371,"w":25,"h":25,"bOffBottom":0,"i":"images/image70.png"}
,
"text19906":{"x":69,"y":271,"w":139,"h":45,"txtscale":100,"bOffBottom":0}
,
"text29927":{"x":69,"y":370,"w":141,"h":75,"txtscale":100,"bOffBottom":0}
,
"text29937":{"x":286,"y":278,"w":137,"h":75,"txtscale":100,"bOffBottom":0}
,
"text29984":{"x":286,"y":370,"w":163,"h":30,"txtscale":100,"bOffBottom":0}
,
"text19907":{"x":36,"y":459,"w":425,"h":51,"txtscale":100,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":[]
}}

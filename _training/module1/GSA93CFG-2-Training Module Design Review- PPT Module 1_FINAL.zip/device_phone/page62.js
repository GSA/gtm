PhoneResponsive={"785":{
"pageLayer":{"w":785,"h":460,"bgColor":"#00324b","bgImage":"images/image0004.png","bgSize":"785px 441px","bgRepeat":"no-repeat"}
,
"":{"x":275,"y":142,"w":233,"h":156,"bOffBottom":0}
,
"":{"x":275,"y":142,"w":233,"h":156,"bOffBottom":0}
,
"image10864":{"x":0,"y":0,"w":785,"h":93,"bOffBottom":0,"i":"images/image0014.png"}
,
"text208202":{"x":700,"y":402,"w":54,"h":15,"txtscale":100,"bOffBottom":0}
,
"text208200":{"x":58,"y":402,"w":49,"h":16,"txtscale":100,"bOffBottom":0}
,
"image10862":{"x":51,"y":406,"w":37,"h":13,"bOffBottom":0,"i":"images/image0002.png"}
,
"image10860":{"x":699,"y":406,"w":37,"h":13,"bOffBottom":0,"i":"images/image0003.png"}
,
"button10847":{"B64":{"disabledState":"","downState":"","normalState":"","overState":"","selectedState":"","visitedState":""},"bOffBottom":0,"h":37,"p":"M 9.000000 0.000000 L 76.000000 0.000000 L 77.812500 0.187500 L 79.500000 0.687500 L 82.375000 2.625000 L 84.312500 5.500000 L 85.000000 9.000000 L 85.000000 27.000000 L 84.312500 30.500000 L 82.375000 33.375000 L 79.500000 35.312500 L 76.000000 36.000000 L 9.000000 36.000000 L 5.562500 35.312500 L 2.687500 33.375000 L 0.687500 30.500000 L 0.000000 27.000000 L 0.000000 9.000000 L 0.187500 7.187500 L 0.687500 5.500000 L 2.625000 2.625000 L 5.500000 0.687500 L 7.187500 0.187500 L 9.000000 0.000000 z","stylemods":[{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10847Text"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.Text"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.Text"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.Text"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.Text"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.Text"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.Text"}],"w":86,"x":39,"y":398}
,
"button10855":{"B64":{"disabledState":"","downState":"","normalState":"","overState":"","selectedState":"","visitedState":""},"bOffBottom":0,"h":37,"p":"M 9.000000 0.000000 L 76.000000 0.000000 L 77.812500 0.187500 L 79.500000 0.687500 L 82.375000 2.625000 L 84.312500 5.500000 L 85.000000 9.000000 L 85.000000 27.000000 L 84.312500 30.500000 L 82.375000 33.375000 L 79.500000 35.312500 L 76.000000 36.000000 L 9.000000 36.000000 L 5.562500 35.312500 L 2.687500 33.375000 L 0.687500 30.500000 L 0.000000 27.000000 L 0.000000 9.000000 L 0.187500 7.187500 L 0.687500 5.500000 L 2.625000 2.625000 L 5.500000 0.687500 L 7.187500 0.187500 L 9.000000 0.000000 z","stylemods":[{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10855Text"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.Text"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.Text"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.Text"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.Text"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.Text"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.Text"}],"w":86,"x":661,"y":398}
,
"progress187611":{"x":54,"y":419,"w":678,"h":14,"bOffBottom":0,"vert":0,"barImage":"images/PhoneLandscape_progress187611_bar.png","bgImage":"images/PhoneLandscape_progress187611.png"}
,
"text193356":{"x":58,"y":420,"w":24,"h":18,"txtscale":100,"bOffBottom":0}
,
"shape78":{"x":51,"y":243,"w":217.000000,"h":149.000000,"stylemods":[{"sel":"div.shape78Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:216.000000px; height:148.000000px;}"},{"sel":"span.shape78Text","decl":" { width:212.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANkAAACVCAYAAADVJF9hAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAACUSURBVHhe7cEBDQAAAMKg909tDwcEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMCzGvnYAAGv+66LAAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 0.000000 0.000000 L 216.000000 0.000000 L 216.000000 148.000000 L 0.000000 148.000000 L 0.000000 0.000000 z"}
,
"shape80":{"x":284,"y":243,"w":217.000000,"h":149.000000,"stylemods":[{"sel":"div.shape80Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:216.000000px; height:148.000000px;}"},{"sel":"span.shape80Text","decl":" { width:212.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANkAAACVCAYAAADVJF9hAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAACUSURBVHhe7cEBDQAAAMKg909tDwcEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMCzGvnYAAGv+66LAAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 0.000000 0.000000 L 216.000000 0.000000 L 216.000000 148.000000 L 0.000000 148.000000 L 0.000000 0.000000 z"}
,
"shape82":{"x":518,"y":243,"w":217.000000,"h":149.000000,"stylemods":[{"sel":"div.shape82Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:216.000000px; height:148.000000px;}"},{"sel":"span.shape82Text","decl":" { width:212.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANkAAACVCAYAAADVJF9hAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAACUSURBVHhe7cEBDQAAAMKg909tDwcEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMCzGvnYAAGv+66LAAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 0.000000 0.000000 L 216.000000 0.000000 L 216.000000 148.000000 L 0.000000 148.000000 L 0.000000 0.000000 z"}
,
"text84":{"x":52,"y":107,"w":113,"h":34,"txtscale":100,"bOffBottom":0}
,
"text85":{"x":172,"y":106,"w":342,"h":60,"txtscale":100,"bOffBottom":0}
,
"text86":{"x":51,"y":148,"w":684,"h":97,"txtscale":100,"bOffBottom":0}
,
"image88":{"x":138,"y":218,"w":41,"h":48,"bOffBottom":0,"i":"images/image0005.png"}
,
"text90":{"x":51,"y":269,"w":213,"h":157,"txtscale":100,"bOffBottom":0}
,
"image92":{"x":372,"y":218,"w":41,"h":48,"bOffBottom":0,"i":"images/image0006.png"}
,
"text94":{"x":284,"y":269,"w":216,"h":157,"txtscale":100,"bOffBottom":0}
,
"image96":{"x":606,"y":218,"w":41,"h":48,"bOffBottom":0,"i":"images/image0007.png"}
,
"text98":{"x":518,"y":269,"w":216,"h":191,"txtscale":100,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":[]
},
"480":{
"pageLayer":{"w":480,"h":763,"bgColor":"#00324b","bgImage":"images/image0004.png","bgSize":"480px 270px","bgRepeat":"no-repeat"}
,
"":{"x":168,"y":183,"w":143,"h":95,"bOffBottom":0}
,
"":{"x":168,"y":183,"w":143,"h":95,"bOffBottom":0}
,
"image10864":{"x":0,"y":0,"w":480,"h":57,"bOffBottom":0,"i":"images/image0014.png"}
,
"text208202":{"x":428,"y":517,"w":33,"h":15,"txtscale":100,"bOffBottom":0}
,
"text208200":{"x":36,"y":517,"w":30,"h":15,"txtscale":100,"bOffBottom":0}
,
"image10862":{"x":31,"y":522,"w":22,"h":8,"bOffBottom":0,"i":"images/image0002.png"}
,
"image10860":{"x":427,"y":522,"w":23,"h":8,"bOffBottom":0,"i":"images/image0003.png"}
,
"button10847":{"B64":{"disabledState":"","downState":"","normalState":"","overState":"","selectedState":"","visitedState":""},"bOffBottom":0,"h":23,"p":"M 5.000000 0.000000 L 47.000000 0.000000 L 48.937500 0.375000 L 50.562500 1.500000 L 51.625000 3.062500 L 52.000000 5.000000 L 52.000000 17.000000 L 51.625000 18.937500 L 50.562500 20.562500 L 48.937500 21.625000 L 47.000000 22.000000 L 5.000000 22.000000 L 3.125000 21.625000 L 1.500000 20.562500 L 0.375000 18.937500 L 0.000000 17.000000 L 0.000000 5.000000 L 0.375000 3.062500 L 1.500000 1.500000 L 3.062500 0.375000 L 5.000000 0.000000 z","stylemods":[{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10847Text"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.Text"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.Text"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.Text"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.Text"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.Text"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.Text"}],"w":53,"x":24,"y":512}
,
"button10855":{"B64":{"disabledState":"","downState":"","normalState":"","overState":"","selectedState":"","visitedState":""},"bOffBottom":0,"h":23,"p":"M 5.000000 0.000000 L 47.000000 0.000000 L 48.937500 0.375000 L 50.562500 1.500000 L 51.625000 3.062500 L 52.000000 5.000000 L 52.000000 17.000000 L 51.625000 18.937500 L 50.562500 20.562500 L 48.937500 21.625000 L 47.000000 22.000000 L 5.000000 22.000000 L 3.125000 21.625000 L 1.500000 20.562500 L 0.375000 18.937500 L 0.000000 17.000000 L 0.000000 5.000000 L 0.375000 3.062500 L 1.500000 1.500000 L 3.062500 0.375000 L 5.000000 0.000000 z","stylemods":[{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10855Text"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.Text"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.Text"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.Text"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.Text"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.Text"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.Text"}],"w":53,"x":404,"y":512}
,
"progress187611":{"x":33,"y":539,"w":415,"h":9,"bOffBottom":0,"vert":0,"barImage":"images/PhonePortrait_progress187611_bar.png","bgImage":"images/PhonePortrait_progress187611.png"}
,
"text193356":{"x":35,"y":540,"w":15,"h":17,"txtscale":100,"bOffBottom":0}
,
"shape78":{"x":31,"y":312,"w":133.000000,"h":91.000000,"stylemods":[{"sel":"div.shape78Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:132.000000px; height:90.000000px;}"},{"sel":"span.shape78Text","decl":" { width:128.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIUAAABbCAYAAABd7kZjAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABFSURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwLcavXcAAZaS1fMAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 132.000000 0.000000 L 132.000000 90.000000 L 0.000000 90.000000 L 0.000000 0.000000 z"}
,
"shape80":{"x":174,"y":312,"w":133.000000,"h":91.000000,"stylemods":[{"sel":"div.shape80Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:132.000000px; height:90.000000px;}"},{"sel":"span.shape80Text","decl":" { width:128.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIUAAABbCAYAAABd7kZjAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABFSURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwLcavXcAAZaS1fMAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 132.000000 0.000000 L 132.000000 90.000000 L 0.000000 90.000000 L 0.000000 0.000000 z"}
,
"shape82":{"x":317,"y":312,"w":133.000000,"h":91.000000,"stylemods":[{"sel":"div.shape82Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:132.000000px; height:90.000000px;}"},{"sel":"span.shape82Text","decl":" { width:128.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIUAAABbCAYAAABd7kZjAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABFSURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwLcavXcAAZaS1fMAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 132.000000 0.000000 L 132.000000 90.000000 L 0.000000 90.000000 L 0.000000 0.000000 z"}
,
"text84":{"x":32,"y":138,"w":69,"h":54,"txtscale":100,"bOffBottom":0}
,
"text85":{"x":105,"y":136,"w":209,"h":64,"txtscale":100,"bOffBottom":0}
,
"text86":{"x":31,"y":190,"w":418,"h":131,"txtscale":100,"bOffBottom":0}
,
"image88":{"x":85,"y":280,"w":25,"h":29,"bOffBottom":0,"i":"images/image0005.png"}
,
"text90":{"x":31,"y":346,"w":130,"h":259,"txtscale":100,"bOffBottom":0}
,
"image92":{"x":227,"y":280,"w":25,"h":29,"bOffBottom":0,"i":"images/image0006.png"}
,
"text94":{"x":174,"y":346,"w":132,"h":276,"txtscale":100,"bOffBottom":0}
,
"image96":{"x":371,"y":280,"w":25,"h":29,"bOffBottom":0,"i":"images/image0007.png"}
,
"text98":{"x":317,"y":346,"w":132,"h":344,"txtscale":100,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":[]
}}

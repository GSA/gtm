PhoneResponsive={"785":{
"pageLayer":{"w":785,"h":501,"bgColor":"#00324b","bgImage":"images/image0004.png","bgSize":"785px 441px","bgRepeat":"no-repeat"}
,
"":{"x":275,"y":142,"w":233,"h":156,"bOffBottom":0}
,
"":{"x":275,"y":142,"w":233,"h":156,"bOffBottom":0}
,
"image10864":{"x":0,"y":0,"w":785,"h":93,"bOffBottom":0,"i":"images/image0014.png"}
,
"text208202":{"x":700,"y":402,"w":54,"h":15,"txtscale":100,"bOffBottom":0}
,
"text208200":{"x":58,"y":402,"w":49,"h":16,"txtscale":100,"bOffBottom":0}
,
"image10862":{"x":51,"y":406,"w":37,"h":13,"bOffBottom":0,"i":"images/image0002.png"}
,
"image10860":{"x":699,"y":406,"w":37,"h":13,"bOffBottom":0,"i":"images/image0003.png"}
,
"button10847":{"B64":{"disabledState":"","downState":"","normalState":"","overState":"","selectedState":"","visitedState":""},"bOffBottom":0,"h":37,"p":"M 9.000000 0.000000 L 76.000000 0.000000 L 77.812500 0.187500 L 79.500000 0.687500 L 82.375000 2.625000 L 84.312500 5.500000 L 85.000000 9.000000 L 85.000000 27.000000 L 84.312500 30.500000 L 82.375000 33.375000 L 79.500000 35.312500 L 76.000000 36.000000 L 9.000000 36.000000 L 5.562500 35.312500 L 2.687500 33.375000 L 0.687500 30.500000 L 0.000000 27.000000 L 0.000000 9.000000 L 0.187500 7.187500 L 0.687500 5.500000 L 2.625000 2.625000 L 5.500000 0.687500 L 7.187500 0.187500 L 9.000000 0.000000 z","stylemods":[{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10847Text"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10847overStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847overStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10847downStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847downStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10847disabledStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847disabledStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10847visitedStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847visitedStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10847selectedStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847selectedStateText"}],"w":86,"x":39,"y":398}
,
"button10855":{"B64":{"disabledState":"","downState":"","normalState":"","overState":"","selectedState":"","visitedState":""},"bOffBottom":0,"h":37,"p":"M 9.000000 0.000000 L 76.000000 0.000000 L 77.812500 0.187500 L 79.500000 0.687500 L 82.375000 2.625000 L 84.312500 5.500000 L 85.000000 9.000000 L 85.000000 27.000000 L 84.312500 30.500000 L 82.375000 33.375000 L 79.500000 35.312500 L 76.000000 36.000000 L 9.000000 36.000000 L 5.562500 35.312500 L 2.687500 33.375000 L 0.687500 30.500000 L 0.000000 27.000000 L 0.000000 9.000000 L 0.187500 7.187500 L 0.687500 5.500000 L 2.625000 2.625000 L 5.500000 0.687500 L 7.187500 0.187500 L 9.000000 0.000000 z","stylemods":[{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10855Text"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10855overStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855overStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10855downStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855downStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10855disabledStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855disabledStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10855visitedStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855visitedStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10855selectedStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855selectedStateText"}],"w":86,"x":661,"y":398}
,
"progress187611":{"x":54,"y":419,"w":678,"h":14,"bOffBottom":0,"vert":0,"barImage":"images/PhoneLandscape_progress187611_bar.png","bgImage":"images/PhoneLandscape_progress187611.png"}
,
"text197831":{"x":493,"y":420,"w":24,"h":18,"txtscale":100,"bOffBottom":0}
,
"text1043":{"x":53,"y":113,"w":342,"h":60,"txtscale":100,"bOffBottom":0}
,
"text1044":{"x":51,"y":148,"w":685,"h":34,"txtscale":100,"bOffBottom":0}
,
"shape1045":{"x":74,"y":176,"w":325.000000,"h":213.000000,"stylemods":[{"sel":"div.shape1045Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:324.000000px; height:212.000000px;}"},{"sel":"span.shape1045Text","decl":" { width:320.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAUUAAADVCAYAAADAZeKqAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAEjSURBVHhe7cGBAAAAAMOg+VMf4ApVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPBqOrUAAa6AP94AAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 324.000000 0.000000 L 324.000000 212.000000 L 0.000000 212.000000 L 0.000000 0.000000 z"}
,
"image1048":{"x":54,"y":195,"w":41,"h":41,"bOffBottom":0,"i":"images/image0079.png"}
,
"text1050":{"x":107,"y":195,"w":267,"h":306,"txtscale":100,"bOffBottom":0}
,
"text1051":{"x":423,"y":176,"w":306,"h":55,"txtscale":100,"bOffBottom":0}
,
"shape1052":{"x":478,"y":243,"w":251.000000,"h":146.000000,"stylemods":[{"sel":"div.shape1052Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:250.000000px; height:145.000000px;}"},{"sel":"span.shape1052Text","decl":" { width:246.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPsAAACSCAYAAACDibw0AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAClSURBVHhe7cEBDQAAAMKg909tDjcgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgFM1PUgAAZ/t1WoAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 250.000000 0.000000 L 250.000000 145.000000 L 0.000000 145.000000 L 0.000000 0.000000 z"}
,
"image1055":{"x":423,"y":262,"w":107,"h":107,"bOffBottom":0,"i":"images/image0080.png"}
,
"text1057":{"x":536,"y":255,"w":174,"h":49,"txtscale":100,"bOffBottom":0}
,
"text1059":{"x":545,"y":298,"w":164,"h":119,"txtscale":100,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":[]
},
"480":{
"pageLayer":{"w":480,"h":763,"bgColor":"#00324b","bgImage":"images/image0004.png","bgSize":"480px 270px","bgRepeat":"no-repeat"}
,
"":{"x":168,"y":183,"w":143,"h":95,"bOffBottom":0}
,
"":{"x":168,"y":183,"w":143,"h":95,"bOffBottom":0}
,
"image10864":{"x":0,"y":0,"w":480,"h":57,"bOffBottom":0,"i":"images/image0014.png"}
,
"text208202":{"x":428,"y":517,"w":33,"h":15,"txtscale":100,"bOffBottom":0}
,
"text208200":{"x":36,"y":517,"w":30,"h":15,"txtscale":100,"bOffBottom":0}
,
"image10862":{"x":31,"y":522,"w":22,"h":8,"bOffBottom":0,"i":"images/image0002.png"}
,
"image10860":{"x":427,"y":522,"w":23,"h":8,"bOffBottom":0,"i":"images/image0003.png"}
,
"button10847":{"B64":{"disabledState":"","downState":"","normalState":"","overState":"","selectedState":"","visitedState":""},"bOffBottom":0,"h":23,"p":"M 5.000000 0.000000 L 47.000000 0.000000 L 48.937500 0.375000 L 50.562500 1.500000 L 51.625000 3.062500 L 52.000000 5.000000 L 52.000000 17.000000 L 51.625000 18.937500 L 50.562500 20.562500 L 48.937500 21.625000 L 47.000000 22.000000 L 5.000000 22.000000 L 3.125000 21.625000 L 1.500000 20.562500 L 0.375000 18.937500 L 0.000000 17.000000 L 0.000000 5.000000 L 0.375000 3.062500 L 1.500000 1.500000 L 3.062500 0.375000 L 5.000000 0.000000 z","stylemods":[{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10847Text"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10847overStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847overStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10847downStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847downStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10847disabledStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847disabledStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10847visitedStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847visitedStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10847selectedStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847selectedStateText"}],"w":53,"x":24,"y":512}
,
"button10855":{"B64":{"disabledState":"","downState":"","normalState":"","overState":"","selectedState":"","visitedState":""},"bOffBottom":0,"h":23,"p":"M 5.000000 0.000000 L 47.000000 0.000000 L 48.937500 0.375000 L 50.562500 1.500000 L 51.625000 3.062500 L 52.000000 5.000000 L 52.000000 17.000000 L 51.625000 18.937500 L 50.562500 20.562500 L 48.937500 21.625000 L 47.000000 22.000000 L 5.000000 22.000000 L 3.125000 21.625000 L 1.500000 20.562500 L 0.375000 18.937500 L 0.000000 17.000000 L 0.000000 5.000000 L 0.375000 3.062500 L 1.500000 1.500000 L 3.062500 0.375000 L 5.000000 0.000000 z","stylemods":[{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10855Text"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10855overStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855overStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10855downStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855downStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10855disabledStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855disabledStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10855visitedStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855visitedStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10855selectedStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855selectedStateText"}],"w":53,"x":404,"y":512}
,
"progress187611":{"x":33,"y":539,"w":415,"h":9,"bOffBottom":0,"vert":0,"barImage":"images/PhonePortrait_progress187611_bar.png","bgImage":"images/PhonePortrait_progress187611.png"}
,
"text197831":{"x":302,"y":540,"w":15,"h":17,"txtscale":100,"bOffBottom":0}
,
"text1043":{"x":32,"y":145,"w":209,"h":38,"txtscale":100,"bOffBottom":0}
,
"text1044":{"x":31,"y":190,"w":419,"h":34,"txtscale":100,"bOffBottom":0}
,
"shape1045":{"x":45,"y":226,"w":199.000000,"h":131.000000,"stylemods":[{"sel":"div.shape1045Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:198.000000px; height:130.000000px;}"},{"sel":"span.shape1045Text","decl":" { width:194.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMcAAACDCAYAAAA5zA+8AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAB8SURBVHhe7cEBDQAAAMKg909tDjcgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAnNZfmAAHY2YcoAAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 0.000000 0.000000 L 198.000000 0.000000 L 198.000000 130.000000 L 0.000000 130.000000 L 0.000000 0.000000 z"}
,
"image1048":{"x":33,"y":251,"w":25,"h":25,"bOffBottom":0,"i":"images/image0079.png"}
,
"text1050":{"x":65,"y":251,"w":163,"h":510,"txtscale":100,"bOffBottom":0}
,
"text1051":{"x":259,"y":226,"w":187,"h":85,"txtscale":100,"bOffBottom":0}
,
"shape1052":{"x":292,"y":312,"w":154.000000,"h":90.000000,"stylemods":[{"sel":"div.shape1052Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:153.000000px; height:89.000000px;}"},{"sel":"span.shape1052Text","decl":" { width:149.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJoAAABaCAYAAABAF0+jAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABNSURBVHhe7cExAQAAAMKg9U9tB28gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgVgPY6gABMqu0gQAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 153.000000 0.000000 L 153.000000 89.000000 L 0.000000 89.000000 L 0.000000 0.000000 z"}
,
"image1055":{"x":259,"y":337,"w":66,"h":65,"bOffBottom":0,"i":"images/image0080.png"}
,
"text1057":{"x":328,"y":328,"w":107,"h":63,"txtscale":100,"bOffBottom":0}
,
"text1059":{"x":333,"y":383,"w":100,"h":204,"txtscale":100,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":[]
}}

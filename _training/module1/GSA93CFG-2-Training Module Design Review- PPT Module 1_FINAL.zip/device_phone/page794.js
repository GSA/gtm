PhoneResponsive={"785":{
"pageLayer":{"w":785,"h":450,"bgColor":"#00324b","bgImage":"images/image0004.png","bgSize":"785px 441px","bgRepeat":"no-repeat"}
,
"":{"x":275,"y":142,"w":233,"h":156,"bOffBottom":0}
,
"":{"x":275,"y":142,"w":233,"h":156,"bOffBottom":0}
,
"image10864":{"x":0,"y":0,"w":785,"h":93,"bOffBottom":0,"i":"images/image0014.png"}
,
"text208202":{"x":700,"y":402,"w":54,"h":15,"txtscale":100,"bOffBottom":0}
,
"text208200":{"x":58,"y":402,"w":49,"h":16,"txtscale":100,"bOffBottom":0}
,
"image10862":{"x":51,"y":406,"w":37,"h":13,"bOffBottom":0,"i":"images/image0002.png"}
,
"image10860":{"x":699,"y":406,"w":37,"h":13,"bOffBottom":0,"i":"images/image0003.png"}
,
"button10847":{"B64":{"disabledState":"","downState":"","normalState":"","overState":"","selectedState":"","visitedState":""},"bOffBottom":0,"h":37,"p":"M 9.000000 0.000000 L 76.000000 0.000000 L 77.812500 0.187500 L 79.500000 0.687500 L 82.375000 2.625000 L 84.312500 5.500000 L 85.000000 9.000000 L 85.000000 27.000000 L 84.312500 30.500000 L 82.375000 33.375000 L 79.500000 35.312500 L 76.000000 36.000000 L 9.000000 36.000000 L 5.562500 35.312500 L 2.687500 33.375000 L 0.687500 30.500000 L 0.000000 27.000000 L 0.000000 9.000000 L 0.187500 7.187500 L 0.687500 5.500000 L 2.625000 2.625000 L 5.500000 0.687500 L 7.187500 0.187500 L 9.000000 0.000000 z","stylemods":[{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10847Text"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10847overStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847overStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10847downStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847downStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10847disabledStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847disabledStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10847visitedStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847visitedStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10847selectedStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847selectedStateText"}],"w":86,"x":39,"y":398}
,
"button10855":{"B64":{"disabledState":"","downState":"","normalState":"","overState":"","selectedState":"","visitedState":""},"bOffBottom":0,"h":37,"p":"M 9.000000 0.000000 L 76.000000 0.000000 L 77.812500 0.187500 L 79.500000 0.687500 L 82.375000 2.625000 L 84.312500 5.500000 L 85.000000 9.000000 L 85.000000 27.000000 L 84.312500 30.500000 L 82.375000 33.375000 L 79.500000 35.312500 L 76.000000 36.000000 L 9.000000 36.000000 L 5.562500 35.312500 L 2.687500 33.375000 L 0.687500 30.500000 L 0.000000 27.000000 L 0.000000 9.000000 L 0.187500 7.187500 L 0.687500 5.500000 L 2.625000 2.625000 L 5.500000 0.687500 L 7.187500 0.187500 L 9.000000 0.000000 z","stylemods":[{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10855Text"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10855overStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855overStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10855downStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855downStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10855disabledStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855disabledStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10855visitedStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855visitedStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button10855selectedStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855selectedStateText"}],"w":86,"x":661,"y":398}
,
"progress187611":{"x":54,"y":419,"w":678,"h":14,"bOffBottom":0,"vert":0,"barImage":"images/PhoneLandscape_progress187611_bar.png","bgImage":"images/PhoneLandscape_progress187611.png"}
,
"text195849":{"x":369,"y":420,"w":24,"h":18,"txtscale":100,"bOffBottom":0}
,
"text796":{"x":53,"y":113,"w":342,"h":44,"txtscale":100,"bOffBottom":0}
,
"text141512":{"x":54,"y":140,"w":342,"h":39,"txtscale":100,"bOffBottom":0}
,
"shape797":{"x":79,"y":171,"w":374.000000,"h":56.000000,"stylemods":[{"sel":"div.shape797Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:373.000000px; height:55.000000px;}"},{"sel":"span.shape797Text","decl":" { width:369.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAXYAAAA4CAYAAADpe9PNAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABnSURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABXakeHAAF9BOIuAAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 0.000000 0.000000 L 373.000000 0.000000 L 373.000000 55.000000 L 0.000000 55.000000 L 0.000000 0.000000 z"}
,
"image799":{"x":59,"y":177,"w":41,"h":41,"bOffBottom":0,"i":"images/image52.png"}
,
"text801":{"x":112,"y":190,"w":279,"h":23,"txtscale":100,"bOffBottom":0}
,
"shape802":{"x":79,"y":241,"w":374.000000,"h":66.000000,"stylemods":[{"sel":"div.shape802Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:373.000000px; height:65.000000px;}"},{"sel":"span.shape802Text","decl":" { width:369.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAXYAAABCCAYAAABDwv1qAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAB2SURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHCoBoIBAAHJ42qOAAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 0.000000 0.000000 L 373.000000 0.000000 L 373.000000 65.000000 L 0.000000 65.000000 L 0.000000 0.000000 z"}
,
"image805":{"x":59,"y":252,"w":41,"h":41,"bOffBottom":0,"i":"images/image0056.png"}
,
"text807":{"x":112,"y":253,"w":323,"h":51,"txtscale":100,"bOffBottom":0}
,
"shape808":{"x":79,"y":319,"w":374.000000,"h":77.000000,"stylemods":[{"sel":"div.shape808Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:373.000000px; height:76.000000px;}"},{"sel":"span.shape808Text","decl":" { width:369.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAXYAAABNCAYAAACylE+/AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAACGSURBVHhe7cEBDQAAAMKg909tDwcEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH2rCVAABviz3uwAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 373.000000 0.000000 L 373.000000 76.000000 L 0.000000 76.000000 L 0.000000 0.000000 z"}
,
"text810":{"x":111,"y":330,"w":323,"h":68,"txtscale":100,"bOffBottom":0}
,
"image811":{"x":59,"y":335,"w":41,"h":41,"bOffBottom":0,"i":"images/image54.png"}
,
"shape813":{"x":492,"y":171,"w":233.000000,"h":129.000000,"stylemods":[{"sel":"div.shape813Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:232.000000px; height:128.000000px;}"},{"sel":"span.shape813Text","decl":" { width:228.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOkAAACBCAYAAAAlkJ3UAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAACMSURBVHhe7cExAQAAAMKg9U9tDB8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD4qgHWNAABf7ANcgAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 232.000000 0.000000 L 232.000000 128.000000 L 0.000000 128.000000 L 0.000000 0.000000 z"}
,
"text815":{"x":531,"y":189,"w":176,"h":170,"txtscale":100,"bOffBottom":0}
,
"image817":{"x":471,"y":184,"w":41,"h":41,"bOffBottom":0,"i":"images/image0057.png"}
,
"shape819":{"x":492,"y":316,"w":233.000000,"h":80.000000,"stylemods":[{"sel":"div.shape819Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:232.000000px; height:79.000000px;}"},{"sel":"span.shape819Text","decl":" { width:228.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOkAAABQCAYAAAD88lJeAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABfSURBVHhe7cExAQAAAMKg9U9tCU8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjmojnwAB0YxNhgAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 232.000000 0.000000 L 232.000000 79.000000 L 0.000000 79.000000 L 0.000000 0.000000 z"}
,
"text821":{"x":530,"y":327,"w":176,"h":85,"txtscale":100,"bOffBottom":0}
,
"image822":{"x":471,"y":325,"w":41,"h":41,"bOffBottom":0,"i":"images/image56.png"}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":[]
},
"480":{
"pageLayer":{"w":480,"h":763,"bgColor":"#00324b","bgImage":"images/image0004.png","bgSize":"480px 270px","bgRepeat":"no-repeat"}
,
"":{"x":168,"y":183,"w":143,"h":95,"bOffBottom":0}
,
"":{"x":168,"y":183,"w":143,"h":95,"bOffBottom":0}
,
"image10864":{"x":0,"y":0,"w":480,"h":57,"bOffBottom":0,"i":"images/image0014.png"}
,
"text208202":{"x":428,"y":517,"w":33,"h":15,"txtscale":100,"bOffBottom":0}
,
"text208200":{"x":36,"y":517,"w":30,"h":15,"txtscale":100,"bOffBottom":0}
,
"image10862":{"x":31,"y":522,"w":22,"h":8,"bOffBottom":0,"i":"images/image0002.png"}
,
"image10860":{"x":427,"y":522,"w":23,"h":8,"bOffBottom":0,"i":"images/image0003.png"}
,
"button10847":{"B64":{"disabledState":"","downState":"","normalState":"","overState":"","selectedState":"","visitedState":""},"bOffBottom":0,"h":23,"p":"M 5.000000 0.000000 L 47.000000 0.000000 L 48.937500 0.375000 L 50.562500 1.500000 L 51.625000 3.062500 L 52.000000 5.000000 L 52.000000 17.000000 L 51.625000 18.937500 L 50.562500 20.562500 L 48.937500 21.625000 L 47.000000 22.000000 L 5.000000 22.000000 L 3.125000 21.625000 L 1.500000 20.562500 L 0.375000 18.937500 L 0.000000 17.000000 L 0.000000 5.000000 L 0.375000 3.062500 L 1.500000 1.500000 L 3.062500 0.375000 L 5.000000 0.000000 z","stylemods":[{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10847Text"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10847overStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847overStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10847downStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847downStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10847disabledStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847disabledStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10847visitedStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847visitedStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10847selectedStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10847selectedStateText"}],"w":53,"x":24,"y":512}
,
"button10855":{"B64":{"disabledState":"","downState":"","normalState":"","overState":"","selectedState":"","visitedState":""},"bOffBottom":0,"h":23,"p":"M 5.000000 0.000000 L 47.000000 0.000000 L 48.937500 0.375000 L 50.562500 1.500000 L 51.625000 3.062500 L 52.000000 5.000000 L 52.000000 17.000000 L 51.625000 18.937500 L 50.562500 20.562500 L 48.937500 21.625000 L 47.000000 22.000000 L 5.000000 22.000000 L 3.125000 21.625000 L 1.500000 20.562500 L 0.375000 18.937500 L 0.000000 17.000000 L 0.000000 5.000000 L 0.375000 3.062500 L 1.500000 1.500000 L 3.062500 0.375000 L 5.000000 0.000000 z","stylemods":[{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10855Text"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10855overStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855overStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10855downStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855downStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10855disabledStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855disabledStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10855visitedStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855visitedStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button10855selectedStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button10855selectedStateText"}],"w":53,"x":404,"y":512}
,
"progress187611":{"x":33,"y":539,"w":415,"h":9,"bOffBottom":0,"vert":0,"barImage":"images/PhonePortrait_progress187611_bar.png","bgImage":"images/PhonePortrait_progress187611.png"}
,
"text195849":{"x":225,"y":540,"w":15,"h":17,"txtscale":100,"bOffBottom":0}
,
"text796":{"x":32,"y":145,"w":209,"h":90,"txtscale":100,"bOffBottom":0}
,
"text141512":{"x":33,"y":180,"w":209,"h":66,"txtscale":100,"bOffBottom":0}
,
"shape797":{"x":49,"y":220,"w":229.000000,"h":35.000000,"stylemods":[{"sel":"div.shape797Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:228.000000px; height:34.000000px;}"},{"sel":"span.shape797Text","decl":" { width:224.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOUAAAAjCAYAAABreM2/AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA2SURBVHhe7cExAQAAAMKg9U9tCy8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgIcafV8AAYkQ+JAAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 228.000000 0.000000 L 228.000000 34.000000 L 0.000000 34.000000 L 0.000000 0.000000 z"}
,
"image799":{"x":36,"y":228,"w":25,"h":25,"bOffBottom":0,"i":"images/image52.png"}
,
"text801":{"x":69,"y":244,"w":171,"h":34,"txtscale":100,"bOffBottom":0}
,
"shape802":{"x":49,"y":310,"w":229.000000,"h":40.000000,"stylemods":[{"sel":"div.shape802Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:228.000000px; height:39.000000px;}"},{"sel":"span.shape802Text","decl":" { width:224.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOUAAAAoCAYAAAABvz18AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA7SURBVHhe7cGBAAAAAMOg+VNf4QBVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwqwGPSAABKvVpjgAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 228.000000 0.000000 L 228.000000 39.000000 L 0.000000 39.000000 L 0.000000 0.000000 z"}
,
"image805":{"x":36,"y":324,"w":25,"h":25,"bOffBottom":0,"i":"images/image0056.png"}
,
"text807":{"x":69,"y":325,"w":197,"h":102,"txtscale":100,"bOffBottom":0}
,
"shape808":{"x":49,"y":410,"w":229.000000,"h":48.000000,"stylemods":[{"sel":"div.shape808Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:228.000000px; height:47.000000px;}"},{"sel":"span.shape808Text","decl":" { width:224.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOUAAAAwCAYAAADuOr2KAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABCSURBVHhe7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAuFUDq/AAATwzutUAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 228.000000 0.000000 L 228.000000 47.000000 L 0.000000 47.000000 L 0.000000 0.000000 z"}
,
"text810":{"x":68,"y":424,"w":197,"h":119,"txtscale":100,"bOffBottom":0}
,
"image811":{"x":36,"y":430,"w":25,"h":25,"bOffBottom":0,"i":"images/image54.png"}
,
"shape813":{"x":301,"y":220,"w":143.000000,"h":79.000000,"stylemods":[{"sel":"div.shape813Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:142.000000px; height:78.000000px;}"},{"sel":"span.shape813Text","decl":" { width:138.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAI8AAABPCAYAAADSi5YnAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABDSURBVHhe7cExAQAAAMKg9U9tCy8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOCvBrDTAAFGIBelAAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 0.000000 0.000000 L 142.000000 0.000000 L 142.000000 78.000000 L 0.000000 78.000000 L 0.000000 0.000000 z"}
,
"text815":{"x":324,"y":243,"w":108,"h":255,"txtscale":100,"bOffBottom":0}
,
"image817":{"x":288,"y":236,"w":25,"h":25,"bOffBottom":0,"i":"images/image0057.png"}
,
"shape819":{"x":301,"y":406,"w":143.000000,"h":50.000000,"stylemods":[{"sel":"div.shape819Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:142.000000px; height:49.000000px;}"},{"sel":"span.shape819Text","decl":" { width:138.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAI8AAAAyCAYAAABlN4g4AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAySURBVHhe7cExAQAAAMKg9U/tZwogAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4Gpv6gAB3wLLbgAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 142.000000 0.000000 L 142.000000 49.000000 L 0.000000 49.000000 L 0.000000 0.000000 z"}
,
"text821":{"x":324,"y":420,"w":108,"h":136,"txtscale":100,"bOffBottom":0}
,
"image822":{"x":288,"y":418,"w":25,"h":25,"bOffBottom":0,"i":"images/image56.png"}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":[]
}}

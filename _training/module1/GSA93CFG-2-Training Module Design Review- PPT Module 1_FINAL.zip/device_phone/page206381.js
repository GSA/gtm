PhoneResponsive={"785":{
"pageLayer":{"w":785,"h":463,"bgColor":"#00324b","bgImage":"images/image0004.png","bgSize":"785px 441px","bgRepeat":"no-repeat"}
,
"text205813":{"x":325,"y":405,"w":140,"h":48,"txtscale":100,"bOffBottom":0}
,
"":{"x":275,"y":142,"w":233,"h":156,"bOffBottom":0}
,
"":{"x":275,"y":142,"w":233,"h":156,"bOffBottom":0}
,
"image10864":{"x":0,"y":0,"w":785,"h":93,"bOffBottom":0,"i":"images/image0014.png"}
,
"progress224458":{"x":54,"y":419,"w":678,"h":14,"bOffBottom":0,"vert":0,"barImage":"images/PhoneLandscape_progress224458_bar.png","bgImage":"images/PhoneLandscape_progress224458.png"}
,
"image225508":{"x":50,"y":410,"w":37,"h":13,"bOffBottom":0,"i":"images/image0002.png"}
,
"image225510":{"x":698,"y":410,"w":37,"h":13,"bOffBottom":0,"i":"images/image0003.png"}
,
"button225517":{"B64":{"disabledState":"","downState":"","normalState":"","overState":"","selectedState":"","visitedState":""},"bOffBottom":0,"h":37,"p":"M 9.000000 0.000000 L 76.000000 0.000000 L 77.812500 0.187500 L 79.500000 0.687500 L 82.375000 2.625000 L 84.312500 5.500000 L 85.000000 9.000000 L 85.000000 27.000000 L 84.312500 30.500000 L 82.375000 33.375000 L 79.500000 35.312500 L 76.000000 36.000000 L 9.000000 36.000000 L 5.562500 35.312500 L 2.687500 33.375000 L 0.687500 30.500000 L 0.000000 27.000000 L 0.000000 9.000000 L 0.187500 7.187500 L 0.687500 5.500000 L 2.625000 2.625000 L 5.500000 0.687500 L 7.187500 0.187500 L 9.000000 0.000000 z","stylemods":[{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button225517Text"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button225517Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button225517overStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button225517overStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button225517downStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button225517downStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button225517disabledStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button225517disabledStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button225517visitedStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button225517visitedStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:85.000000px; height:36.000000px;}","sel":"div.button225517selectedStateText"},{"decl":" { width:77.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button225517selectedStateText"}],"w":86,"x":39,"y":398}
,
"text225519":{"x":700,"y":401,"w":156,"h":62,"txtscale":100,"bOffBottom":0}
,
"text225520":{"x":58,"y":401,"w":156,"h":62,"txtscale":100,"bOffBottom":0}
,
"text206406":{"x":53,"y":113,"w":342,"h":38,"txtscale":100,"bOffBottom":0}
,
"shape206408":{"x":58,"y":213,"w":23.000000,"h":67.000000,"stylemods":[{"sel":"div.shape206408Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:22.000000px; height:66.000000px;}"},{"sel":"span.shape206408Text","decl":" { width:18.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAABDCAYAAAB3NZ5BAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAdSURBVFhH7cGBAAAAAMOg+VNf4QBVAAAAAAAAjxoYVwABDFuqwAAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 22.000000 0.000000 L 22.000000 66.000000 L 0.000000 66.000000 L 0.000000 0.000000 z"}
,
"shape206410":{"x":86,"y":213,"w":472.000000,"h":67.000000,"stylemods":[{"sel":"div.shape206410Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:471.000000px; height:66.000000px;}"},{"sel":"span.shape206410Text","decl":" { width:467.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAdgAAABDCAYAAAA/DxStAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAACSSURBVHhe7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4UgPucgAB8zlOagAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 471.000000 0.000000 L 471.000000 66.000000 L 0.000000 66.000000 L 0.000000 0.000000 z"}
,
"shape206412":{"x":58,"y":286,"w":23.000000,"h":35.000000,"stylemods":[{"sel":"div.shape206412Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:22.000000px; height:34.000000px;}"},{"sel":"span.shape206412Text","decl":" { width:18.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAAjCAYAAAB/wZEbAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAaSURBVEhL7cExAQAAAMKg9U9tDQ8gAACAZzUMtwABejQyXgAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 22.000000 0.000000 L 22.000000 34.000000 L 0.000000 34.000000 L 0.000000 0.000000 z"}
,
"shape206414":{"x":86,"y":286,"w":472.000000,"h":35.000000,"stylemods":[{"sel":"div.shape206414Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:471.000000px; height:34.000000px;}"},{"sel":"span.shape206414Text","decl":" { width:467.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAdgAAAAjCAYAAAA3+xv3AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABXSURBVHhe7cExAQAAAMKg9U9tCF8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgFcNAlIAAeecqcEAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 471.000000 0.000000 L 471.000000 34.000000 L 0.000000 34.000000 L 0.000000 0.000000 z"}
,
"shape206416":{"x":58,"y":324,"w":23.000000,"h":26.000000,"stylemods":[{"sel":"div.shape206416Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:22.000000px; height:25.000000px;}"},{"sel":"span.shape206416Text","decl":" { width:18.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAAaCAYAAABctMd+AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCj8gAACuaglyAAHt7btKAAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 0.000000 0.000000 L 22.000000 0.000000 L 22.000000 25.000000 L 0.000000 25.000000 L 0.000000 0.000000 z"}
,
"shape206418":{"x":86,"y":325,"w":472.000000,"h":24.000000,"stylemods":[{"sel":"div.shape206418Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:471.000000px; height:23.000000px;}"},{"sel":"span.shape206418Text","decl":" { width:467.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAdgAAAAYCAYAAABZRuyZAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABDSURBVHhe7cEBDQAAAMKg909tDjcgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOBUDbEYAAHEK+syAAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 0.000000 0.000000 L 471.000000 0.000000 L 471.000000 23.000000 L 0.000000 23.000000 L 0.000000 0.000000 z"}
,
"shape206420":{"x":58,"y":172,"w":23.000000,"h":37.000000,"stylemods":[{"sel":"div.shape206420Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:22.000000px; height:36.000000px;}"},{"sel":"span.shape206420Text","decl":" { width:18.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAAlCAYAAACpmHIGAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAaSURBVEhL7cExAQAAAMKg9U9tCj8gAAAAHmoNcQABFSDzuwAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 22.000000 0.000000 L 22.000000 36.000000 L 0.000000 36.000000 L 0.000000 0.000000 z"}
,
"shape206422":{"x":86,"y":172,"w":472.000000,"h":37.000000,"stylemods":[{"sel":"div.shape206422Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:471.000000px; height:36.000000px;}"},{"sel":"span.shape206422Text","decl":" { width:467.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAdgAAAAlCAYAAADhovjqAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABaSURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8KEGERQAAT4w+DQAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 471.000000 0.000000 L 471.000000 36.000000 L 0.000000 36.000000 L 0.000000 0.000000 z"}
,
"text206423":{"x":65,"y":178,"w":33,"h":84,"txtscale":100,"bOffBottom":0}
,
"text206424":{"x":87,"y":178,"w":431,"h":51,"txtscale":100,"bOffBottom":0}
,
"text206425":{"x":65,"y":240,"w":22,"h":23,"txtscale":100,"bOffBottom":0}
,
"text206426":{"x":86,"y":219,"w":464,"h":102,"txtscale":100,"bOffBottom":0}
,
"text206427":{"x":65,"y":293,"w":22,"h":29,"txtscale":100,"bOffBottom":0}
,
"text206428":{"x":87,"y":291,"w":481,"h":51,"txtscale":100,"bOffBottom":0}
,
"text206439":{"x":58,"y":148,"w":567,"h":22,"txtscale":100,"bOffBottom":0}
,
"text206440":{"x":590,"y":179,"w":23,"h":26,"txtscale":100,"bOffBottom":0}
,
"check206441":{"x":583,"y":178,"fsize":19,"bOffBottom":0}
,
"text206442":{"x":657,"y":177,"w":23,"h":26,"txtscale":100,"bOffBottom":0}
,
"check206443":{"x":650,"y":178,"fsize":19,"bOffBottom":0}
,
"text206444":{"x":720,"y":179,"w":23,"h":26,"txtscale":100,"bOffBottom":0}
,
"check206445":{"x":714,"y":178,"fsize":19,"bOffBottom":0}
,
"text206446":{"x":590,"y":235,"w":21,"h":26,"txtscale":100,"bOffBottom":0}
,
"check206447":{"x":583,"y":235,"fsize":19,"bOffBottom":0}
,
"text206448":{"x":657,"y":233,"w":21,"h":26,"txtscale":100,"bOffBottom":0}
,
"check206449":{"x":650,"y":235,"fsize":19,"bOffBottom":0}
,
"text206450":{"x":720,"y":234,"w":21,"h":26,"txtscale":100,"bOffBottom":0}
,
"check206451":{"x":714,"y":235,"fsize":19,"bOffBottom":0}
,
"text206452":{"x":590,"y":288,"w":21,"h":26,"txtscale":100,"bOffBottom":0}
,
"check206453":{"x":583,"y":289,"fsize":19,"bOffBottom":0}
,
"text206454":{"x":657,"y":289,"w":21,"h":26,"txtscale":100,"bOffBottom":0}
,
"check206455":{"x":650,"y":289,"fsize":19,"bOffBottom":0}
,
"text206456":{"x":720,"y":289,"w":21,"h":26,"txtscale":100,"bOffBottom":0}
,
"check206457":{"x":714,"y":289,"fsize":19,"bOffBottom":0}
,
"text206458":{"x":586,"y":328,"w":21,"h":26,"txtscale":100,"bOffBottom":0}
,
"check206459":{"x":583,"y":327,"fsize":19,"bOffBottom":0}
,
"text206460":{"x":657,"y":327,"w":21,"h":26,"txtscale":100,"bOffBottom":0}
,
"check206461":{"x":650,"y":327,"fsize":19,"bOffBottom":0}
,
"text206462":{"x":720,"y":326,"w":21,"h":26,"txtscale":100,"bOffBottom":0}
,
"check206463":{"x":714,"y":327,"fsize":19,"bOffBottom":0}
,
"shape206431":{"x":356,"y":359,"w":71.000000,"h":32.000000,"stylemods":[{"sel":"div.shape206431Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:70.000000px; height:31.000000px;}"},{"sel":"span.shape206431Text","decl":" { width:66.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEcAAAAgCAYAAABAQWX9AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAgSURBVGhD7cExAQAAAMKg9U9tCj8gAAAAAAAAAADgpAYjoAAByJ/3wgAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 70.000000 0.000000 L 70.000000 31.000000 L 0.000000 31.000000 L 0.000000 0.000000 z"}
,
"text206434":{"x":240,"y":361,"w":301,"h":23,"txtscale":100,"bOffBottom":0}
,
"button219691":{"B64":{"disabledState":"","downState":"","normalState":"","overState":"","selectedState":"","visitedState":""},"bOffBottom":0,"h":33,"p":"M 8.000000 0.000000 L 61.000000 0.000000 L 64.125000 0.625000 L 66.687500 2.375000 L 68.375000 4.875000 L 69.000000 8.000000 L 69.000000 24.000000 L 68.375000 27.125000 L 66.687500 29.687500 L 64.125000 31.375000 L 61.000000 32.000000 L 8.000000 32.000000 L 5.000000 31.437500 L 2.375000 29.687500 L 0.625000 27.062500 L 0.000000 24.000000 L 0.000000 8.000000 L 0.625000 4.875000 L 2.375000 2.375000 L 4.875000 0.625000 L 8.000000 0.000000 z","stylemods":[{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:69.000000px; height:32.000000px;}","sel":"div.button219691Text"},{"decl":" { width:61.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button219691Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:69.000000px; height:32.000000px;}","sel":"div.button219691overStateText"},{"decl":" { width:61.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button219691overStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:69.000000px; height:32.000000px;}","sel":"div.button219691downStateText"},{"decl":" { width:61.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button219691downStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:69.000000px; height:32.000000px;}","sel":"div.button219691disabledStateText"},{"decl":" { width:61.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button219691disabledStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:69.000000px; height:32.000000px;}","sel":"div.button219691visitedStateText"},{"decl":" { width:61.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button219691visitedStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:69.000000px; height:32.000000px;}","sel":"div.button219691selectedStateText"},{"decl":" { width:61.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button219691selectedStateText"}],"w":70,"x":357,"y":358}
,
"text206464":{"x":58,"y":359,"w":295,"h":51,"txtscale":100,"bOffBottom":0}
,
"text206465":{"x":65,"y":329,"w":22,"h":23,"txtscale":100,"bOffBottom":0}
,
"text206466":{"x":87,"y":331,"w":442,"h":34,"txtscale":100,"bOffBottom":0}
,
"text206467":{"x":570,"y":142,"w":52,"h":29,"txtscale":100,"bOffBottom":0}
,
"text206468":{"x":631,"y":142,"w":66,"h":34,"txtscale":100,"bOffBottom":0}
,
"text206469":{"x":709,"y":142,"w":37,"h":30,"txtscale":100,"bOffBottom":0}
,
"shape206472":{"x":0,"y":0,"w":786.000000,"h":443.000000,"stylemods":[{"sel":"div.shape206472Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:785.000000px; height:442.000000px;}"},{"sel":"span.shape206472Text","decl":" { width:781.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAxIAAAG7CAYAAABXSKPEAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAVdSURBVHhe7cGBAAAAAMOg+VMf4QJVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATw1DjgAB1zSgdQAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 785.000000 0.000000 L 785.000000 442.000000 L 0.000000 442.000000 L 0.000000 0.000000 z"}
,
"shape206474":{"x":81,"y":131,"w":623.000000,"h":271.000000,"stylemods":[{"sel":"div.shape206474Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:622.000000px; height:270.000000px;}"},{"sel":"span.shape206474Text","decl":" { width:618.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAnEAAAERCAYAAAAUkfH/AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAKtSURBVHhe7cExAQAAAMKg9U9tCy8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPioAWurAAFWNk27AAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 1.000000 1.000000 L 621.000000 1.000000 L 621.000000 269.000000 L 1.000000 269.000000 L 1.000000 1.000000 z"}
,
"shape206476":{"x":672,"y":140,"w":22.000000,"h":22.000000,"stylemods":[{"sel":"div.shape206476Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:21.000000px; height:21.000000px;}"},{"sel":"span.shape206476Text","decl":" { width:17.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAYAAADEtGw7AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAYSURBVEhLYxgFo2AUjIJRMApGwaAEDAwAB6YAATgpF14AAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 1.000000 1.000000 L 20.000000 1.000000 L 20.000000 20.000000 L 1.000000 20.000000 L 1.000000 1.000000 z"}
,
"image206479":{"x":676,"y":144,"w":14,"h":14,"bOffBottom":0,"i":"images/image0092.png"}
,
"shape206482":{"x":81,"y":131,"w":104.000000,"h":34.000000,"stylemods":[{"sel":"div.shape206482Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:103.000000px; height:33.000000px;}"},{"sel":"span.shape206482Text","decl":" { width:99.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGgAAAAiCAYAAACz35yrAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAkSURBVGhD7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAcKgGN2IAAQIAFEoAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 103.000000 0.000000 L 103.000000 33.000000 L 0.000000 33.000000 L 0.000000 0.000000 z"}
,
"text206483":{"x":90,"y":137,"w":82,"h":20,"txtscale":100,"bOffBottom":0}
,
"text206484":{"x":109,"y":184,"w":78,"h":160,"txtscale":100,"bOffBottom":0}
,
"image206486":{"x":6,"y":101,"w":21,"h":20,"bOffBottom":0,"i":"images/image0090.png"}
,
"text206487":{"x":156,"y":210,"w":517,"h":71,"txtscale":100,"bOffBottom":0}
,
"image206489":{"x":6,"y":101,"w":21,"h":20,"bOffBottom":0,"i":"images/image0090.png"}
,
"text206490":{"x":156,"y":257,"w":529,"h":77,"txtscale":100,"bOffBottom":0}
,
"image206492":{"x":6,"y":101,"w":21,"h":20,"bOffBottom":0,"i":"images/image0090.png"}
,
"text206493":{"x":156,"y":311,"w":518,"h":65,"txtscale":100,"bOffBottom":0}
,
"image206495":{"x":6,"y":101,"w":21,"h":20,"bOffBottom":0,"i":"images/image0090.png"}
,
"text206496":{"x":156,"y":350,"w":519,"h":51,"txtscale":100,"bOffBottom":0}
,
"shape206499":{"x":0,"y":0,"w":786.000000,"h":443.000000,"stylemods":[{"sel":"div.shape206499Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:785.000000px; height:442.000000px;}"},{"sel":"span.shape206499Text","decl":" { width:781.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAxIAAAG7CAYAAABXSKPEAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAVdSURBVHhe7cGBAAAAAMOg+VMf4QJVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATw1DjgAB1zSgdQAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 785.000000 0.000000 L 785.000000 442.000000 L 0.000000 442.000000 L 0.000000 0.000000 z"}
,
"shape206501":{"x":81,"y":131,"w":623.000000,"h":271.000000,"stylemods":[{"sel":"div.shape206501Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:622.000000px; height:270.000000px;}"},{"sel":"span.shape206501Text","decl":" { width:618.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAnEAAAERCAYAAAAUkfH/AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAKtSURBVHhe7cExAQAAAMKg9U9tCy8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPioAWurAAFWNk27AAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 1.000000 1.000000 L 621.000000 1.000000 L 621.000000 269.000000 L 1.000000 269.000000 L 1.000000 1.000000 z"}
,
"shape206503":{"x":672,"y":140,"w":22.000000,"h":22.000000,"stylemods":[{"sel":"div.shape206503Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:21.000000px; height:21.000000px;}"},{"sel":"span.shape206503Text","decl":" { width:17.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAYAAADEtGw7AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAYSURBVEhLYxgFo2AUjIJRMApGwaAEDAwAB6YAATgpF14AAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 1.000000 1.000000 L 20.000000 1.000000 L 20.000000 20.000000 L 1.000000 20.000000 L 1.000000 1.000000 z"}
,
"image206506":{"x":676,"y":144,"w":14,"h":14,"bOffBottom":0,"i":"images/image0092.png"}
,
"shape206509":{"x":81,"y":131,"w":104.000000,"h":34.000000,"stylemods":[{"sel":"div.shape206509Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:103.000000px; height:33.000000px;}"},{"sel":"span.shape206509Text","decl":" { width:99.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGgAAAAiCAYAAACz35yrAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAkSURBVGhD7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAcKgGN2IAAQIAFEoAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 103.000000 0.000000 L 103.000000 33.000000 L 0.000000 33.000000 L 0.000000 0.000000 z"}
,
"text206510":{"x":90,"y":137,"w":82,"h":20,"txtscale":100,"bOffBottom":0}
,
"text206511":{"x":109,"y":184,"w":78,"h":160,"txtscale":100,"bOffBottom":0}
,
"image206513":{"x":6,"y":101,"w":21,"h":20,"bOffBottom":0,"i":"images/image0090.png"}
,
"text206514":{"x":156,"y":210,"w":517,"h":71,"txtscale":100,"bOffBottom":0}
,
"image206516":{"x":6,"y":101,"w":21,"h":20,"bOffBottom":0,"i":"images/image0090.png"}
,
"text206517":{"x":156,"y":257,"w":529,"h":77,"txtscale":100,"bOffBottom":0}
,
"image206519":{"x":6,"y":101,"w":21,"h":20,"bOffBottom":0,"i":"images/image0090.png"}
,
"text206520":{"x":156,"y":308,"w":518,"h":65,"txtscale":100,"bOffBottom":0}
,
"image206522":{"x":6,"y":101,"w":21,"h":20,"bOffBottom":0,"i":"images/image0090.png"}
,
"text206523":{"x":156,"y":350,"w":519,"h":51,"txtscale":100,"bOffBottom":0}
,
"shape206526":{"x":0,"y":0,"w":786.000000,"h":443.000000,"stylemods":[{"sel":"div.shape206526Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:785.000000px; height:442.000000px;}"},{"sel":"span.shape206526Text","decl":" { width:781.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAxIAAAG7CAYAAABXSKPEAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAVdSURBVHhe7cGBAAAAAMOg+VMf4QJVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATw1DjgAB1zSgdQAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 785.000000 0.000000 L 785.000000 442.000000 L 0.000000 442.000000 L 0.000000 0.000000 z"}
,
"shape206528":{"x":87,"y":143,"w":437.000000,"h":79.000000,"stylemods":[{"sel":"div.shape206528Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:436.000000px; height:78.000000px;}"},{"sel":"span.shape206528Text","decl":" { width:432.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAbcAAABRCAYAAABR/ejAAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAChSURBVHhe7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgWQ0sCwABKwFCZwAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 1.000000 1.000000 L 435.000000 1.000000 L 435.000000 77.000000 L 1.000000 77.000000 L 1.000000 1.000000 z"}
,
"shape206530":{"x":87,"y":143,"w":90.000000,"h":34.000000,"stylemods":[{"sel":"div.shape206530Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:89.000000px; height:33.000000px;}"},{"sel":"span.shape206530Text","decl":" { width:85.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFoAAAAiCAYAAADf2c6uAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAjSURBVGhD7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAADgTg0v8gABJb68SwAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 89.000000 0.000000 L 89.000000 33.000000 L 0.000000 33.000000 L 0.000000 0.000000 z"}
,
"text206531":{"x":101,"y":179,"w":622,"h":39,"txtscale":100,"bOffBottom":0}
,
"text206532":{"x":89,"y":151,"w":79,"h":20,"txtscale":100,"bOffBottom":0}
,
"shape206534":{"x":495,"y":149,"w":22.000000,"h":22.000000,"stylemods":[{"sel":"div.shape206534Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:21.000000px; height:21.000000px;}"},{"sel":"span.shape206534Text","decl":" { width:17.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAYAAADEtGw7AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAYSURBVEhLYxgFo2AUjIJRMApGwaAEDAwAB6YAATgpF14AAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 1.000000 1.000000 L 20.000000 1.000000 L 20.000000 20.000000 L 1.000000 20.000000 L 1.000000 1.000000 z"}
,
"image206537":{"x":499,"y":152,"w":14,"h":14,"bOffBottom":0,"i":"images/image0093.png"}
,
"button219935":{"B64":{"disabledState":"","downState":"","normalState":"","overState":"","selectedState":"","visitedState":""},"bOffBottom":0,"h":32,"p":"M 7.000000 0.000000 L 86.000000 0.000000 L 88.750000 0.562500 L 90.937500 2.062500 L 92.437500 4.312500 L 93.000000 7.000000 L 93.000000 24.000000 L 92.437500 26.750000 L 90.937500 28.937500 L 88.750000 30.437500 L 86.000000 31.000000 L 7.000000 31.000000 L 4.375000 30.500000 L 2.062500 29.000000 L 0.562500 26.687500 L 0.000000 24.000000 L 0.000000 7.000000 L 0.562500 4.312500 L 2.062500 2.062500 L 4.312500 0.562500 L 7.000000 0.000000 z","stylemods":[{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:93.000000px; height:31.000000px;}","sel":"div.button219935Text"},{"decl":" { width:87.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button219935Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:93.000000px; height:31.000000px;}","sel":"div.button219935overStateText"},{"decl":" { width:87.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button219935overStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:93.000000px; height:31.000000px;}","sel":"div.button219935downStateText"},{"decl":" { width:87.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button219935downStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:93.000000px; height:31.000000px;}","sel":"div.button219935disabledStateText"},{"decl":" { width:87.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button219935disabledStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:93.000000px; height:31.000000px;}","sel":"div.button219935visitedStateText"},{"decl":" { width:87.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button219935visitedStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:93.000000px; height:31.000000px;}","sel":"div.button219935selectedStateText"},{"decl":" { width:87.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button219935selectedStateText"}],"w":94,"x":659,"y":394}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":[]
},
"480":{
"pageLayer":{"w":480,"h":1031,"bgColor":"#00324b","bgImage":"images/image0004.png","bgSize":"480px 270px","bgRepeat":"no-repeat"}
,
"text205813":{"x":199,"y":520,"w":86,"h":60,"txtscale":100,"bOffBottom":0}
,
"":{"x":168,"y":183,"w":143,"h":95,"bOffBottom":0}
,
"":{"x":168,"y":183,"w":143,"h":95,"bOffBottom":0}
,
"image10864":{"x":0,"y":0,"w":480,"h":57,"bOffBottom":0,"i":"images/image0014.png"}
,
"progress224458":{"x":33,"y":539,"w":415,"h":9,"bOffBottom":0,"vert":0,"barImage":"images/PhonePortrait_progress224458_bar.png","bgImage":"images/PhonePortrait_progress224458.png"}
,
"image225508":{"x":30,"y":527,"w":22,"h":8,"bOffBottom":0,"i":"images/image0002.png"}
,
"image225510":{"x":427,"y":527,"w":23,"h":8,"bOffBottom":0,"i":"images/image0003.png"}
,
"button225517":{"B64":{"disabledState":"","downState":"","normalState":"","overState":"","selectedState":"","visitedState":""},"bOffBottom":0,"h":23,"p":"M 5.000000 0.000000 L 47.000000 0.000000 L 48.937500 0.375000 L 50.562500 1.500000 L 51.625000 3.062500 L 52.000000 5.000000 L 52.000000 17.000000 L 51.625000 18.937500 L 50.562500 20.562500 L 48.937500 21.625000 L 47.000000 22.000000 L 5.000000 22.000000 L 3.125000 21.625000 L 1.500000 20.562500 L 0.375000 18.937500 L 0.000000 17.000000 L 0.000000 5.000000 L 0.375000 3.062500 L 1.500000 1.500000 L 3.062500 0.375000 L 5.000000 0.000000 z","stylemods":[{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button225517Text"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button225517Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button225517overStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button225517overStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button225517downStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button225517downStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button225517disabledStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button225517disabledStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button225517visitedStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button225517visitedStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:52.000000px; height:22.000000px;}","sel":"div.button225517selectedStateText"},{"decl":" { width:46.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button225517selectedStateText"}],"w":53,"x":24,"y":512}
,
"text225519":{"x":428,"y":516,"w":95,"h":38,"txtscale":100,"bOffBottom":0}
,
"text225520":{"x":36,"y":516,"w":95,"h":38,"txtscale":100,"bOffBottom":0}
,
"text206406":{"x":32,"y":145,"w":209,"h":38,"txtscale":100,"bOffBottom":0}
,
"shape206408":{"x":35,"y":274,"w":14.000000,"h":41.000000,"stylemods":[{"sel":"div.shape206408Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:13.000000px; height:40.000000px;}"},{"sel":"span.shape206408Text","decl":" { width:9.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAApCAYAAAAF4RhfAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U/tawggAABeDQkhAAHGJSa+AAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 0.000000 0.000000 L 13.000000 0.000000 L 13.000000 40.000000 L 0.000000 40.000000 L 0.000000 0.000000 z"}
,
"shape206410":{"x":52,"y":274,"w":289.000000,"h":41.000000,"stylemods":[{"sel":"div.shape206410Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:288.000000px; height:40.000000px;}"},{"sel":"span.shape206410Text","decl":" { width:284.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASEAAAApCAYAAAB6OZ/CAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABFSURBVHhe7cEBDQAAAMKg909tDwcEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPKsBuU0AAShvH9QAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 288.000000 0.000000 L 288.000000 40.000000 L 0.000000 40.000000 L 0.000000 0.000000 z"}
,
"shape206412":{"x":35,"y":367,"w":14.000000,"h":22.000000,"stylemods":[{"sel":"div.shape206412Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:13.000000px; height:21.000000px;}"},{"sel":"span.shape206412Text","decl":" { width:9.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAWCAYAAADwza0nAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAATSURBVDhPYxgFo2AUjIJhDBgYAATmAAEiZ4R7AAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 0.000000 0.000000 L 13.000000 0.000000 L 13.000000 21.000000 L 0.000000 21.000000 L 0.000000 0.000000 z"}
,
"shape206414":{"x":52,"y":367,"w":289.000000,"h":22.000000,"stylemods":[{"sel":"div.shape206414Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:288.000000px; height:21.000000px;}"},{"sel":"span.shape206414Text","decl":" { width:284.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASEAAAAWCAYAAACPFSq6AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAwSURBVHhe7cEBDQAAAMKg909tDjcgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOFEDY24AAUzzj18AAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 288.000000 0.000000 L 288.000000 21.000000 L 0.000000 21.000000 L 0.000000 0.000000 z"}
,
"shape206416":{"x":35,"y":417,"w":14.000000,"h":16.000000,"stylemods":[{"sel":"div.shape206416Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:13.000000px; height:15.000000px;}"},{"sel":"span.shape206416Text","decl":" { width:9.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:6px; font-size:6px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAQCAYAAAAmlE46AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAASSURBVDhPYxgFo2AUDBLAwAAAA5AAAQOrbMgAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 13.000000 0.000000 L 13.000000 15.000000 L 0.000000 15.000000 L 0.000000 0.000000 z"}
,
"shape206418":{"x":52,"y":418,"w":289.000000,"h":15.000000,"stylemods":[{"sel":"div.shape206418Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:288.000000px; height:14.000000px;}"},{"sel":"span.shape206418Text","decl":" { width:284.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASEAAAAPCAYAAACrzHnpAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAoSURBVHhe7cExAQAAAMKg9U9tCF8gAAAAAAAAAAAAAAAAAAAAAOBXA0PLAAHiq1VWAAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 0.000000 0.000000 L 288.000000 0.000000 L 288.000000 14.000000 L 0.000000 14.000000 L 0.000000 0.000000 z"}
,
"shape206420":{"x":35,"y":221,"w":14.000000,"h":23.000000,"stylemods":[{"sel":"div.shape206420Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:13.000000px; height:22.000000px;}"},{"sel":"span.shape206420Text","decl":" { width:9.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAXCAYAAAA7kX6CAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAUSURBVDhPYxgFo2AUjIJRgAkYGAAFHwAB6t1NEQAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 13.000000 0.000000 L 13.000000 22.000000 L 0.000000 22.000000 L 0.000000 0.000000 z"}
,
"shape206422":{"x":52,"y":221,"w":289.000000,"h":23.000000,"stylemods":[{"sel":"div.shape206422Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:288.000000px; height:22.000000px;}"},{"sel":"span.shape206422Text","decl":" { width:284.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASEAAAAXCAYAAABESfkfAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAxSURBVHhe7cGBAAAAAMOg+VMf4QJVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMBXA2fzAAEdSQm9AAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 0.000000 0.000000 L 288.000000 0.000000 L 288.000000 22.000000 L 0.000000 22.000000 L 0.000000 0.000000 z"}
,
"text206423":{"x":40,"y":229,"w":20,"h":84,"txtscale":100,"bOffBottom":0}
,
"text206424":{"x":53,"y":229,"w":264,"h":68,"txtscale":100,"bOffBottom":0}
,
"text206425":{"x":40,"y":308,"w":13,"h":23,"txtscale":100,"bOffBottom":0}
,
"text206426":{"x":53,"y":282,"w":284,"h":136,"txtscale":100,"bOffBottom":0}
,
"text206427":{"x":40,"y":377,"w":13,"h":23,"txtscale":100,"bOffBottom":0}
,
"text206428":{"x":53,"y":374,"w":294,"h":85,"txtscale":100,"bOffBottom":0}
,
"text206439":{"x":66,"y":95,"w":347,"h":64,"txtscale":100,"bOffBottom":0}
,
"text206440":{"x":103,"y":167,"w":310,"h":64,"txtscale":100,"bOffBottom":0}
,
"check206441":{"x":63,"y":169,"fsize":19,"bOffBottom":0}
,
"text206442":{"x":103,"y":239,"w":310,"h":64,"txtscale":100,"bOffBottom":0}
,
"check206443":{"x":63,"y":241,"fsize":19,"bOffBottom":0}
,
"text206444":{"x":103,"y":311,"w":310,"h":64,"txtscale":100,"bOffBottom":0}
,
"check206445":{"x":63,"y":313,"fsize":19,"bOffBottom":0}
,
"text206446":{"x":103,"y":383,"w":310,"h":64,"txtscale":100,"bOffBottom":0}
,
"check206447":{"x":63,"y":385,"fsize":19,"bOffBottom":0}
,
"text206448":{"x":103,"y":455,"w":310,"h":64,"txtscale":100,"bOffBottom":0}
,
"check206449":{"x":63,"y":457,"fsize":19,"bOffBottom":0}
,
"text206450":{"x":103,"y":527,"w":310,"h":64,"txtscale":100,"bOffBottom":0}
,
"check206451":{"x":63,"y":529,"fsize":19,"bOffBottom":0}
,
"text206452":{"x":103,"y":599,"w":310,"h":64,"txtscale":100,"bOffBottom":0}
,
"check206453":{"x":63,"y":601,"fsize":19,"bOffBottom":0}
,
"text206454":{"x":103,"y":671,"w":310,"h":64,"txtscale":100,"bOffBottom":0}
,
"check206455":{"x":63,"y":673,"fsize":19,"bOffBottom":0}
,
"text206456":{"x":103,"y":743,"w":310,"h":64,"txtscale":100,"bOffBottom":0}
,
"check206457":{"x":63,"y":745,"fsize":19,"bOffBottom":0}
,
"text206458":{"x":103,"y":815,"w":310,"h":64,"txtscale":100,"bOffBottom":0}
,
"check206459":{"x":63,"y":817,"fsize":19,"bOffBottom":0}
,
"text206460":{"x":103,"y":887,"w":310,"h":64,"txtscale":100,"bOffBottom":0}
,
"check206461":{"x":63,"y":889,"fsize":19,"bOffBottom":0}
,
"text206462":{"x":103,"y":959,"w":310,"h":64,"txtscale":100,"bOffBottom":0}
,
"check206463":{"x":63,"y":961,"fsize":19,"bOffBottom":0}
,
"shape206431":{"x":218,"y":461,"w":44.000000,"h":20.000000,"stylemods":[{"sel":"div.shape206431Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:43.000000px; height:19.000000px;}"},{"sel":"span.shape206431Text","decl":" { width:39.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAUCAYAAAD2rd/BAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAbSURBVEhL7cEBDQAAAMKg909tDjcgAAAATtUADdQAAdxorBwAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 43.000000 0.000000 L 43.000000 19.000000 L 0.000000 19.000000 L 0.000000 0.000000 z"}
,
"text206434":{"x":147,"y":464,"w":184,"h":18,"txtscale":100,"bOffBottom":0}
,
"button219691":{"B64":{"disabledState":"","downState":"","normalState":"","overState":"","selectedState":"","visitedState":""},"bOffBottom":0,"h":21,"p":"M 5.000000 0.000000 L 37.000000 0.000000 L 38.937500 0.375000 L 40.562500 1.500000 L 41.625000 3.062500 L 42.000000 5.000000 L 42.000000 15.000000 L 41.625000 16.937500 L 40.562500 18.562500 L 38.937500 19.625000 L 37.000000 20.000000 L 5.000000 20.000000 L 3.125000 19.625000 L 1.500000 18.562500 L 0.375000 16.937500 L 0.000000 15.000000 L 0.000000 5.000000 L 0.375000 3.062500 L 1.500000 1.500000 L 3.062500 0.375000 L 5.000000 0.000000 z","stylemods":[{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:42.000000px; height:20.000000px;}","sel":"div.button219691Text"},{"decl":" { width:36.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button219691Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:42.000000px; height:20.000000px;}","sel":"div.button219691overStateText"},{"decl":" { width:36.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button219691overStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:42.000000px; height:20.000000px;}","sel":"div.button219691downStateText"},{"decl":" { width:36.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button219691downStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:42.000000px; height:20.000000px;}","sel":"div.button219691disabledStateText"},{"decl":" { width:36.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button219691disabledStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:42.000000px; height:20.000000px;}","sel":"div.button219691visitedStateText"},{"decl":" { width:36.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button219691visitedStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:42.000000px; height:20.000000px;}","sel":"div.button219691selectedStateText"},{"decl":" { width:36.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button219691selectedStateText"}],"w":43,"x":218,"y":460}
,
"text206464":{"x":36,"y":461,"w":180,"h":68,"txtscale":100,"bOffBottom":0}
,
"text206465":{"x":40,"y":423,"w":13,"h":23,"txtscale":100,"bOffBottom":0}
,
"text206466":{"x":53,"y":425,"w":270,"h":51,"txtscale":100,"bOffBottom":0}
,
"text206467":{"x":349,"y":182,"w":32,"h":18,"txtscale":100,"bOffBottom":0}
,
"text206468":{"x":386,"y":182,"w":40,"h":34,"txtscale":100,"bOffBottom":0}
,
"text206469":{"x":433,"y":182,"w":22,"h":19,"txtscale":100,"bOffBottom":0}
,
"shape206472":{"x":0,"y":0,"w":481.000000,"h":271.000000,"stylemods":[{"sel":"div.shape206472Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:480.000000px; height:270.000000px;}"},{"sel":"span.shape206472Text","decl":" { width:476.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAeEAAAEPCAYAAAB1BHz8AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAIQSURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfKsB9jQAAao7MmQAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 480.000000 0.000000 L 480.000000 270.000000 L 0.000000 270.000000 L 0.000000 0.000000 z"}
,
"shape206474":{"x":49,"y":169,"w":381.000000,"h":166.000000,"stylemods":[{"sel":"div.shape206474Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:380.000000px; height:165.000000px;}"},{"sel":"span.shape206474Text","decl":" { width:376.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAX8AAACoCAYAAAAICO5EAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAERSURBVHhe7cExAQAAAMKg9U9tB28gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAuNUA7jUAAej5kJIAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 1.000000 1.000000 L 379.000000 1.000000 L 379.000000 164.000000 L 1.000000 164.000000 L 1.000000 1.000000 z"}
,
"shape206476":{"x":411,"y":180,"w":14.000000,"h":14.000000,"stylemods":[{"sel":"div.shape206476Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:13.000000px; height:13.000000px;}"},{"sel":"span.shape206476Text","decl":" { width:9.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAOCAYAAAAfSC3RAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAARSURBVDhPYxgFo2AUYAUMDAADHgABs1fwVgAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 1.000000 1.000000 L 12.000000 1.000000 L 12.000000 12.000000 L 1.000000 12.000000 L 1.000000 1.000000 z"}
,
"image206479":{"x":413,"y":185,"w":9,"h":9,"bOffBottom":0,"i":"images/image0092.png"}
,
"shape206482":{"x":49,"y":169,"w":64.000000,"h":21.000000,"stylemods":[{"sel":"div.shape206482Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:63.000000px; height:20.000000px;}"},{"sel":"span.shape206482Text","decl":" { width:59.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAAAVCAYAAAD2KuiaAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAbSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAD9qFRUAAaUGzp4AAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 63.000000 0.000000 L 63.000000 20.000000 L 0.000000 20.000000 L 0.000000 0.000000 z"}
,
"text206483":{"x":55,"y":176,"w":50,"h":18,"txtscale":100,"bOffBottom":0}
,
"text206484":{"x":67,"y":237,"w":48,"h":160,"txtscale":100,"bOffBottom":0}
,
"image206486":{"x":4,"y":101,"w":13,"h":12,"bOffBottom":0,"i":"images/image0090.png"}
,
"text206487":{"x":95,"y":270,"w":316,"h":113,"txtscale":100,"bOffBottom":0}
,
"image206489":{"x":4,"y":101,"w":13,"h":12,"bOffBottom":0,"i":"images/image0090.png"}
,
"text206490":{"x":95,"y":330,"w":323,"h":111,"txtscale":100,"bOffBottom":0}
,
"image206492":{"x":4,"y":101,"w":13,"h":12,"bOffBottom":0,"i":"images/image0090.png"}
,
"text206493":{"x":95,"y":400,"w":317,"h":77,"txtscale":100,"bOffBottom":0}
,
"image206495":{"x":4,"y":101,"w":13,"h":12,"bOffBottom":0,"i":"images/image0090.png"}
,
"text206496":{"x":95,"y":450,"w":317,"h":68,"txtscale":100,"bOffBottom":0}
,
"shape206499":{"x":0,"y":0,"w":481.000000,"h":271.000000,"stylemods":[{"sel":"div.shape206499Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:480.000000px; height:270.000000px;}"},{"sel":"span.shape206499Text","decl":" { width:476.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAeEAAAEPCAYAAAB1BHz8AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAIQSURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfKsB9jQAAao7MmQAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 480.000000 0.000000 L 480.000000 270.000000 L 0.000000 270.000000 L 0.000000 0.000000 z"}
,
"shape206501":{"x":49,"y":169,"w":381.000000,"h":166.000000,"stylemods":[{"sel":"div.shape206501Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:380.000000px; height:165.000000px;}"},{"sel":"span.shape206501Text","decl":" { width:376.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAX8AAACoCAYAAAAICO5EAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAERSURBVHhe7cExAQAAAMKg9U9tB28gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAuNUA7jUAAej5kJIAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 1.000000 1.000000 L 379.000000 1.000000 L 379.000000 164.000000 L 1.000000 164.000000 L 1.000000 1.000000 z"}
,
"shape206503":{"x":411,"y":180,"w":14.000000,"h":14.000000,"stylemods":[{"sel":"div.shape206503Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:13.000000px; height:13.000000px;}"},{"sel":"span.shape206503Text","decl":" { width:9.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAOCAYAAAAfSC3RAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAARSURBVDhPYxgFo2AUYAUMDAADHgABs1fwVgAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 1.000000 1.000000 L 12.000000 1.000000 L 12.000000 12.000000 L 1.000000 12.000000 L 1.000000 1.000000 z"}
,
"image206506":{"x":413,"y":185,"w":9,"h":9,"bOffBottom":0,"i":"images/image0092.png"}
,
"shape206509":{"x":49,"y":169,"w":64.000000,"h":21.000000,"stylemods":[{"sel":"div.shape206509Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:63.000000px; height:20.000000px;}"},{"sel":"span.shape206509Text","decl":" { width:59.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAAAVCAYAAAD2KuiaAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAbSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAD9qFRUAAaUGzp4AAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 63.000000 0.000000 L 63.000000 20.000000 L 0.000000 20.000000 L 0.000000 0.000000 z"}
,
"text206510":{"x":55,"y":176,"w":50,"h":18,"txtscale":100,"bOffBottom":0}
,
"text206511":{"x":67,"y":237,"w":48,"h":160,"txtscale":100,"bOffBottom":0}
,
"image206513":{"x":4,"y":101,"w":13,"h":12,"bOffBottom":0,"i":"images/image0090.png"}
,
"text206514":{"x":95,"y":270,"w":316,"h":113,"txtscale":100,"bOffBottom":0}
,
"image206516":{"x":4,"y":101,"w":13,"h":12,"bOffBottom":0,"i":"images/image0090.png"}
,
"text206517":{"x":95,"y":330,"w":323,"h":111,"txtscale":100,"bOffBottom":0}
,
"image206519":{"x":4,"y":101,"w":13,"h":12,"bOffBottom":0,"i":"images/image0090.png"}
,
"text206520":{"x":95,"y":396,"w":317,"h":77,"txtscale":100,"bOffBottom":0}
,
"image206522":{"x":4,"y":101,"w":13,"h":12,"bOffBottom":0,"i":"images/image0090.png"}
,
"text206523":{"x":95,"y":450,"w":317,"h":68,"txtscale":100,"bOffBottom":0}
,
"shape206526":{"x":0,"y":0,"w":481.000000,"h":271.000000,"stylemods":[{"sel":"div.shape206526Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:480.000000px; height:270.000000px;}"},{"sel":"span.shape206526Text","decl":" { width:476.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAeEAAAEPCAYAAAB1BHz8AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAIQSURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfKsB9jQAAao7MmQAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 480.000000 0.000000 L 480.000000 270.000000 L 0.000000 270.000000 L 0.000000 0.000000 z"}
,
"shape206528":{"x":53,"y":184,"w":267.000000,"h":49.000000,"stylemods":[{"sel":"div.shape206528Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:266.000000px; height:48.000000px;}"},{"sel":"span.shape206528Text","decl":" { width:262.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQ0AAAAzCAYAAACNFV1hAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABLSURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9q1o8AASn2vb4AAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 1.000000 1.000000 L 265.000000 1.000000 L 265.000000 47.000000 L 1.000000 47.000000 L 1.000000 1.000000 z"}
,
"shape206530":{"x":53,"y":184,"w":55.000000,"h":21.000000,"stylemods":[{"sel":"div.shape206530Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:54.000000px; height:20.000000px;}"},{"sel":"span.shape206530Text","decl":" { width:50.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADcAAAAVCAYAAADiv3Z7AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAbSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAPKsBEiEAARxlZkQAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 54.000000 0.000000 L 54.000000 20.000000 L 0.000000 20.000000 L 0.000000 0.000000 z"}
,
"text206531":{"x":62,"y":230,"w":381,"h":52,"txtscale":100,"bOffBottom":0}
,
"text206532":{"x":54,"y":194,"w":48,"h":17,"txtscale":100,"bOffBottom":0}
,
"shape206534":{"x":303,"y":191,"w":14.000000,"h":14.000000,"stylemods":[{"sel":"div.shape206534Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:13.000000px; height:13.000000px;}"},{"sel":"span.shape206534Text","decl":" { width:9.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAOCAYAAAAfSC3RAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAARSURBVDhPYxgFo2AUYAUMDAADHgABs1fwVgAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 1.000000 1.000000 L 12.000000 1.000000 L 12.000000 12.000000 L 1.000000 12.000000 L 1.000000 1.000000 z"}
,
"image206537":{"x":305,"y":196,"w":9,"h":9,"bOffBottom":0,"i":"images/image0093.png"}
,
"button219935":{"B64":{"disabledState":"","downState":"","normalState":"","overState":"","selectedState":"","visitedState":""},"bOffBottom":0,"h":20,"p":"M 4.000000 0.000000 L 53.000000 0.000000 L 54.562500 0.312500 L 55.875000 1.187500 L 56.687500 2.437500 L 57.000000 4.000000 L 57.000000 15.000000 L 56.687500 16.562500 L 55.875000 17.875000 L 54.562500 18.687500 L 53.000000 19.000000 L 4.000000 19.000000 L 2.500000 18.750000 L 1.187500 17.875000 L 0.312500 16.562500 L 0.000000 15.000000 L 0.000000 4.000000 L 0.312500 2.437500 L 1.187500 1.187500 L 2.437500 0.312500 L 4.000000 0.000000 z","stylemods":[{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:57.000000px; height:19.000000px;}","sel":"div.button219935Text"},{"decl":" { width:51.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button219935Text"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:57.000000px; height:19.000000px;}","sel":"div.button219935overStateText"},{"decl":" { width:51.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button219935overStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:57.000000px; height:19.000000px;}","sel":"div.button219935downStateText"},{"decl":" { width:51.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button219935downStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:57.000000px; height:19.000000px;}","sel":"div.button219935disabledStateText"},{"decl":" { width:51.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button219935disabledStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:57.000000px; height:19.000000px;}","sel":"div.button219935visitedStateText"},{"decl":" { width:51.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button219935visitedStateText"},{"decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:57.000000px; height:19.000000px;}","sel":"div.button219935selectedStateText"},{"decl":" { width:51.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button219935selectedStateText"}],"w":58,"x":403,"y":507}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":[]
}}

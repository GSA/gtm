DesktopResponsive={"1009":{
"pageLayer":{"w":1009,"h":567,"bgColor":"#00324b","bgImage":"images/image0000.png","bgSize":"1009px 567px","bgRepeat":"no-repeat"}
,
"":{"x":354,"y":183,"w":300,"h":200,"bOffBottom":0}
,
"":{"x":354,"y":183,"w":300,"h":200,"bOffBottom":0}
,
"image10864":{"x":0,"y":0,"w":1009,"h":120,"bOffBottom":0,"i":"images/image0014.png"}
,
"shape3495":{"x":97,"y":403,"w":815.000000,"h":4.000000,"stylemods":[{"sel":"div.shape3495Text","decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:811.000000px; height:0.000000px;}"},{"sel":"span.shape3495Text","decl":" { width:807.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAy0AAAACCAYAAABVAjN4AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAdSURBVFhH7cExAQAAAMKg9U9tB28gAAAAAAAALjUZagABEw263AAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 2.000000 2.000000 L 813.000000 2.000000 " ,"i":"images/shape3495.png"}
,
"shape3497":{"x":97,"y":210,"w":815.000000,"h":4.000000,"stylemods":[{"sel":"div.shape3497Text","decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:811.000000px; height:0.000000px;}"},{"sel":"span.shape3497Text","decl":" { width:807.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAy0AAAACCAYAAABVAjN4AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAdSURBVFhH7cExAQAAAMKg9U9tB28gAAAAAAAALjUZagABEw263AAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 2.000000 2.000000 L 813.000000 2.000000 " ,"i":"images/shape3497.png"}
,
"shape3499":{"x":430,"y":172,"w":141.000000,"h":48.000000,"stylemods":[{"sel":"div.shape3499Text","decl":" { position:absolute; top:0.000000px; left:0.000000px; display:flex; justify-content:center; align-items:center; width:140.000000px; height:47.000000px;}"},{"sel":"span.shape3499Text","decl":" { width:136.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAI0AAAAwCAYAAAAsCvkOAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAxSURBVHhe7cGBAAAAAMOg+VPf4ARVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcNWnwAAE4iJe/AAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 0.000000 0.000000 L 140.000000 0.000000 L 140.000000 47.000000 L 0.000000 47.000000 L 0.000000 0.000000 z" ,"i":"images/shape3499.png"}
,
"text3501":{"x":252,"y":178,"w":502,"h":49,"txtscale":100,"bOffBottom":0}
,
"text3502":{"x":70,"y":236,"w":866,"h":99,"txtscale":100,"bOffBottom":0}
,
"text3503":{"x":24,"y":330,"w":960,"h":53,"txtscale":100,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":[]
}}
